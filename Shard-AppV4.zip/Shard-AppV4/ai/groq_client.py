"""
Shard App — Groq AI Client
Interface com a Groq API usando aiohttp para chamadas assíncronas.
"""

from __future__ import annotations

import json
import logging
from typing import Any, Optional

import aiohttp

from config.settings import GROQ_API_KEY

logger = logging.getLogger("shard.groq")

GROQ_API_URL = "https://api.groq.com/openai/v1/chat/completions"


class GroqClient:
    """Cliente assíncrono para a Groq API."""

    def __init__(self, api_key: str = GROQ_API_KEY) -> None:
        self.api_key = api_key
        self._session: Optional[aiohttp.ClientSession] = None

    async def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json",
                }
            )
        return self._session

    async def close(self) -> None:
        if self._session and not self._session.closed:
            await self._session.close()

    async def chat(
        self,
        messages: list[dict[str, str]],
        model: str = "llama-3.1-8b-instant",   # fallback; callers always pass model explicitly
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> Optional[str]:
        """
        Envia uma requisição de chat para a Groq API.
        Retorna o conteúdo da resposta ou None em caso de erro.
        """
        session = await self._get_session()
        payload = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }

        try:
            async with session.post(GROQ_API_URL, json=payload) as resp:
                if resp.status != 200:
                    text = await resp.text()
                    logger.error("Groq API retornou %d: %s", resp.status, text)
                    return None
                data = await resp.json()
                return data["choices"][0]["message"]["content"]
        except aiohttp.ClientError as e:
            logger.error("Erro de rede ao chamar Groq API: %s", e)
            return None
        except (KeyError, IndexError, json.JSONDecodeError) as e:
            logger.error("Resposta inesperada da Groq API: %s", e)
            return None

    async def generate_json(
        self,
        prompt: str,
        system: str,
        model: str = "llama-3.1-8b-instant",
    ) -> Optional[dict]:
        """
        Chama a Groq API esperando uma resposta em JSON válido.
        Tenta extrair o JSON mesmo que venha com texto ao redor.
        """
        messages = [
            {"role": "system", "content": system},
            {"role": "user", "content": prompt},
        ]
        content = await self.chat(messages, model=model, temperature=0.5, max_tokens=4096)
        if not content:
            return None

        # Tentar extrair JSON do conteúdo
        return _extract_json(content)


def _extract_json(text: str) -> Optional[dict]:
    """Extrai o primeiro objeto JSON válido de um texto."""
    # Tentar parse direto
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    # Procurar por bloco ```json ... ```
    import re
    pattern = r"```(?:json)?\s*(\{.*?\})\s*```"
    match = re.search(pattern, text, re.DOTALL)
    if match:
        try:
            return json.loads(match.group(1))
        except json.JSONDecodeError:
            pass

    # Tentar encontrar o primeiro { ... } balanceado
    start = text.find("{")
    if start == -1:
        return None

    depth = 0
    for i, ch in enumerate(text[start:], start):
        if ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                try:
                    return json.loads(text[start : i + 1])
                except json.JSONDecodeError:
                    return None
    return None
