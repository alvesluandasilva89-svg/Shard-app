"""
Shard App — Utilitários Gerais
Funções auxiliares reutilizáveis em todo o projeto.
"""

from __future__ import annotations

import datetime
import logging
from typing import Optional

import discord

logger = logging.getLogger("shard.helpers")


def format_date(dt: Optional[datetime.datetime]) -> str:
    """Formata uma data para exibição amigável."""
    if dt is None:
        return "N/A"
    return f"<t:{int(dt.timestamp())}:D>"


def days_remaining(expires_at_iso: Optional[str]) -> Optional[int]:
    """Calcula dias restantes até expiração. Retorna None se não houver expiração."""
    if not expires_at_iso:
        return None
    exp = datetime.datetime.fromisoformat(expires_at_iso)
    delta = exp - datetime.datetime.utcnow()
    return max(0, delta.days)


def chunk_list(lst: list, size: int) -> list[list]:
    """Divide uma lista em sublistas de tamanho máximo definido."""
    return [lst[i : i + size] for i in range(0, len(lst), size)]


async def safe_send_dm(user: discord.User | discord.Member, **kwargs) -> bool:
    """Tenta enviar DM ao usuário. Retorna True se bem-sucedido."""
    try:
        await user.send(**kwargs)
        return True
    except (discord.Forbidden, discord.HTTPException):
        logger.debug("Não foi possível enviar DM para %s (%d)", user.name, user.id)
        return False


async def safe_delete_channels(
    guild: discord.Guild,
    bot_member: discord.Member,
) -> tuple[int, list[str]]:
    """
    Remove todos os canais que o bot tem permissão para excluir.
    Retorna (quantidade removida, lista de erros).
    """
    removed = 0
    errors: list[str] = []

    for channel in list(guild.channels):
        try:
            await channel.delete(reason="Shard App — Recriação de servidor")
            removed += 1
        except discord.Forbidden:
            errors.append(f"Sem permissão: {channel.name}")
        except discord.HTTPException as e:
            errors.append(f"Erro ao remover {channel.name}: {e}")

    return removed, errors


async def safe_delete_roles(
    guild: discord.Guild,
    bot_member: discord.Member,
) -> tuple[int, list[str]]:
    """
    Remove todos os cargos que o bot pode excluir (abaixo da hierarquia do bot).
    Preserva @everyone e cargos com ADMINISTRATOR.
    """
    removed = 0
    errors: list[str] = []
    bot_top = bot_member.top_role.position

    for role in list(guild.roles):
        # Nunca remover: @everyone, cargos acima ou igual ao bot, administradores gerenciados
        if (
            role.is_default()
            or role.position >= bot_top
            or role.managed
        ):
            continue
        try:
            await role.delete(reason="Shard App — Recriação de servidor")
            removed += 1
        except discord.Forbidden:
            errors.append(f"Sem permissão: {role.name}")
        except discord.HTTPException as e:
            errors.append(f"Erro ao remover {role.name}: {e}")

    return removed, errors


def color_from_hex(hex_str: str) -> discord.Color:
    """Converte string hex (#RRGGBB) em discord.Color."""
    try:
        clean = hex_str.lstrip("#")
        return discord.Color(int(clean, 16))
    except (ValueError, AttributeError):
        return discord.Color(0x00BFFF)


def truncate(text: str, max_len: int = 1024) -> str:
    """Trunca texto ao limite de campo de embed."""
    if len(text) <= max_len:
        return text
    return text[: max_len - 3] + "..."


def role_permissions_from_list(perms: list[str]) -> discord.Permissions:
    """Converte lista de strings de permissão em discord.Permissions."""
    p = discord.Permissions.none()
    perm_map = {
        "send_messages":      "send_messages",
        "read_messages":      "read_messages",
        "manage_messages":    "manage_messages",
        "manage_channels":    "manage_channels",
        "manage_roles":       "manage_roles",
        "kick_members":       "kick_members",
        "ban_members":        "ban_members",
        "administrator":      "administrator",
        "embed_links":        "embed_links",
        "attach_files":       "attach_files",
        "mention_everyone":   "mention_everyone",
        "use_voice_activation": "use_voice_activation",
        "connect":            "connect",
        "speak":              "speak",
        "mute_members":       "mute_members",
        "deafen_members":     "deafen_members",
        "move_members":       "move_members",
        "view_channel":       "view_channel",
        "view_audit_log":     "view_audit_log",
        "manage_guild":       "manage_guild",
    }
    kwargs = {}
    for perm in perms:
        key = perm_map.get(perm.lower().replace(" ", "_"))
        if key:
            kwargs[key] = True
    if kwargs:
        p = discord.Permissions(**kwargs)
    return p
