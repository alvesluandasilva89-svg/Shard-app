"""
Shard App — Embed Builders
Centraliza a criação de todas as embeds do bot.
"""

from __future__ import annotations

import datetime
from typing import Optional

import discord

from config.settings import (
    BOT_COLOR, BOT_COLOR_ERROR, BOT_COLOR_SUCCESS, BOT_COLOR_WARNING,
    BOT_COLOR_BRONZE, BOT_COLOR_EMERALD, BOT_COLOR_DIAMOND,
    FOOTER_TEXT, THUMBNAIL_URL, PLANS, SERVIDOR_OFICIAL_URL, BOT_NAME, EMOJI,
)


def _base(
    title: str,
    description: str = "",
    color: int = BOT_COLOR,
    thumbnail: bool = True,
    timestamp: bool = True,
) -> discord.Embed:
    e = discord.Embed(title=title, description=description or "", color=color)
    if timestamp:
        e.timestamp = datetime.datetime.utcnow()
    e.set_footer(text=FOOTER_TEXT, icon_url=THUMBNAIL_URL)
    if thumbnail:
        e.set_thumbnail(url=THUMBNAIL_URL)
    return e


# ── Genéricas ─────────────────────────────────────────────────────────────────

def success_embed(title: str, description: str = "") -> discord.Embed:
    return _base(f"✅  {title}", description, BOT_COLOR_SUCCESS)


def error_embed(title: str, description: str = "") -> discord.Embed:
    return _base(f"❌  {title}", description, BOT_COLOR_ERROR)


def warning_embed(title: str, description: str = "") -> discord.Embed:
    return _base(f"⚠️  {title}", description, BOT_COLOR_WARNING)


def info_embed(title: str, description: str = "") -> discord.Embed:
    return _base(f"ℹ️  {title}", description, BOT_COLOR)


def loading_embed(step: str) -> discord.Embed:
    e = discord.Embed(
        title=f"{EMOJI['rocket']}  Shard App — Construindo...",
        description=(
            f"{EMOJI['bot']} O Shard App está configurando seu servidor com **IA**.\n"
            f"Isso pode levar até **60 segundos** — aguarde!\n\u200b"
        ),
        color=0x5865F2,
        timestamp=datetime.datetime.utcnow(),
    )
    e.add_field(
        name=f"{EMOJI['setting']}  Status atual",
        value=f"```\n{step}\n```",
        inline=False,
    )
    e.add_field(
        name=f"{EMOJI['data']}  Powered by",
        value="Groq AI  ·  Shard Cloud",
        inline=True,
    )
    e.set_footer(text=FOOTER_TEXT, icon_url=THUMBNAIL_URL)
    e.set_thumbnail(url=THUMBNAIL_URL)
    return e


# ── Ping ──────────────────────────────────────────────────────────────────────

def ping_embed(latency_ms: int) -> discord.Embed:
    if latency_ms < 100:
        status, color = "🟢 Excelente", BOT_COLOR_SUCCESS
    elif latency_ms < 200:
        status, color = "🟡 Bom", BOT_COLOR_WARNING
    else:
        status, color = "🔴 Lento", BOT_COLOR_ERROR

    e = _base(f"🏓  Pong!", color=color, thumbnail=False)
    e.description = f"Conexão verificada com sucesso.\n\u200b"
    e.add_field(name=f"{EMOJI['data']}  Latência",  value=f"**{latency_ms} ms**",  inline=True)
    e.add_field(name=f"{EMOJI['bot']}  Status",     value=status,                  inline=True)
    e.add_field(name=f"{EMOJI['star']}  Servidor",  value="Shard Cloud",           inline=True)
    return e


# ── Perfil ────────────────────────────────────────────────────────────────────

def profile_embed(
    user: discord.Member | discord.User,
    premium_data: dict,
    daily_used: int,
    backup_count: int,
    total_servers: int,
    days_remaining: Optional[int] = None,
) -> discord.Embed:
    plan_key = premium_data.get("plan", "free")
    plan = PLANS[plan_key]
    color_map = {
        "free":    BOT_COLOR,
        "bronze":  BOT_COLOR_BRONZE,
        "emerald": BOT_COLOR_EMERALD,
        "diamond": BOT_COLOR_DIAMOND,
    }
    color = color_map.get(plan_key, BOT_COLOR)
    daily_limit = plan["daily_limit"]

    if daily_limit == 0:
        bar = "█" * 10
        remaining_text = "∞ Ilimitado"
        usage_label = f"{daily_used}/∞"
    else:
        bar_filled = round((daily_used / daily_limit) * 10) if daily_limit else 0
        bar = "█" * bar_filled + "░" * (10 - bar_filled)
        remaining = max(0, daily_limit - daily_used)
        remaining_text = f"**{remaining}** restantes"
        usage_label = f"{daily_used}/{daily_limit}"

    e = discord.Embed(
        title=f"{plan['badge']}  Perfil — {user.display_name}",
        color=color,
        timestamp=datetime.datetime.utcnow(),
    )
    e.set_author(name=str(user), icon_url=user.display_avatar.url)
    e.set_thumbnail(url=user.display_avatar.url)
    e.set_footer(text=FOOTER_TEXT, icon_url=THUMBNAIL_URL)

    plan_value = f"{plan['emoji']}  **{plan['name']}**"
    if days_remaining is not None and plan_key != "free":
        plan_value += f"\n⏳ `{days_remaining}` dias restantes"
    elif plan_key == "free":
        plan_value += f"\n[Fazer Upgrade]({SERVIDOR_OFICIAL_URL})"

    e.add_field(
        name=f"{EMOJI['member']}  Usuário",
        value=(
            f"**Nome:** {user.mention}\n"
            f"**ID:** `{user.id}`\n"
            f"**Conta:** <t:{int(user.created_at.timestamp())}:D>"
        ),
        inline=True,
    )
    e.add_field(
        name=f"{EMOJI['crown']}  Plano",
        value=plan_value,
        inline=True,
    )
    if isinstance(user, discord.Member) and user.joined_at:
        e.add_field(
            name=f"{EMOJI['new_member']}  No Servidor",
            value=f"Entrou <t:{int(user.joined_at.timestamp())}:R>",
            inline=True,
        )

    e.add_field(
        name=f"{EMOJI['data']}  Uso Diário — `{usage_label}`",
        value=f"`{bar}` {remaining_text}",
        inline=False,
    )
    e.add_field(name=f"{EMOJI['categories']}  Backups",       value=f"**{backup_count}**",   inline=True)
    e.add_field(name=f"{EMOJI['rocket']}  Servidores Criados", value=f"**{total_servers}**", inline=True)
    e.add_field(name=f"{EMOJI['star']}  Plano Atual",          value=f"**{plan['name']}**",  inline=True)

    return e


# ── Planos (detalhe individual) ───────────────────────────────────────────────

def plan_detail_embed(plan_key: str = "free") -> discord.Embed:
    """Embed com detalhes de UM plano específico — estilo premium."""
    plan = PLANS[plan_key]
    daily = "∞ Ilimitadas" if plan["daily_limit"] == 0 else f"{plan['daily_limit']}/dia"

    e = discord.Embed(
        title=f"{plan['emoji']}  {plan['name']}",
        description=f"**{plan['tagline']}**\n> {plan['subtitle']}",
        color=plan["color"],
        timestamp=datetime.datetime.utcnow(),
    )
    e.set_thumbnail(url=THUMBNAIL_URL)
    e.set_footer(text=FOOTER_TEXT, icon_url=THUMBNAIL_URL)

    e.add_field(
        name=f"{EMOJI['gift']}  Preço",
        value=f"**{plan['price']}**",
        inline=True,
    )
    e.add_field(
        name=f"{EMOJI['rocket']}  Criações/Dia",
        value=f"**{daily}**",
        inline=True,
    )
    e.add_field(
        name=f"{EMOJI['shieldys']}  Benefícios",
        value="\n".join(f"{b}" for b in plan["benefits"]),
        inline=False,
    )
    e.add_field(
        name=f"{EMOJI['star_link']}  Como Adquirir",
        value=f"Acesse o [**Servidor Oficial**]({SERVIDOR_OFICIAL_URL}) e abra um ticket de compra.",
        inline=False,
    )
    return e


def plans_embed() -> discord.Embed:
    """Embed inicial de planos (redireciona para plan_detail_embed via PlansView)."""
    return plan_detail_embed("free")


# ── Premium Bloqueado ─────────────────────────────────────────────────────────

def premium_required_embed(
    required_plan: str,
    current_plan: str,
    reason: str = "Este recurso",
) -> discord.Embed:
    req = PLANS[required_plan]
    cur = PLANS[current_plan]
    e = _base(
        f"🔒  Recurso Exclusivo — {req['name']}",
        (
            f"{reason} requer o plano **{req['emoji']} {req['name']}** ou superior.\n"
            f"Seu plano atual: **{cur['emoji']} {cur['name']}**\n\u200b"
        ),
        req["color"],
    )
    e.add_field(
        name=f"{req['emoji']}  {req['name']} — {req['price']}",
        value="\n".join(f"{b}" for b in req["benefits"][:5]),
        inline=False,
    )
    e.add_field(
        name=f"{EMOJI['star_link']}  Adquirir",
        value=f"[**Servidor Oficial**]({SERVIDOR_OFICIAL_URL})",
        inline=True,
    )
    return e


# ── Limite Diário ─────────────────────────────────────────────────────────────

def daily_limit_embed(current_plan: str, used: int, limit: int) -> discord.Embed:
    plan = PLANS[current_plan]
    bar = "█" * 10
    limit_text = "∞ Ilimitado" if limit == 0 else str(limit)
    e = _base(
        "⏳  Limite Diário Atingido",
        (
            f"Você usou todas as **{limit_text}** criações disponíveis hoje "
            f"no plano **{plan['emoji']} {plan['name']}**.\n"
            "> 🔄 As criações renovam à **meia-noite UTC**.\n\u200b"
        ),
        BOT_COLOR_WARNING,
    )
    e.add_field(
        name=f"{EMOJI['data']}  Uso Hoje",
        value=f"`{bar}` — **{used}/{limit_text}** utilizados",
        inline=False,
    )
    comparison = ""
    for key, p in PLANS.items():
        arrow = "**›** " if key == current_plan else "     "
        dl = "∞" if p['daily_limit'] == 0 else str(p['daily_limit'])
        comparison += f"\n{arrow}{p['emoji']} **{p['name']}** — `{dl}`/dia"
    e.add_field(
        name=f"{EMOJI['crown']}  Compare os Planos",
        value=comparison.strip(),
        inline=False,
    )
    return e


# ── Backup ────────────────────────────────────────────────────────────────────

def backup_created_embed(
    name: str, channels: int, categories: int, roles: int, elapsed: float
) -> discord.Embed:
    e = _base(
        f"{EMOJI['categories']}  Backup Criado!",
        f"O backup **{name}** foi salvo com sucesso e pode ser restaurado a qualquer momento.\n\u200b",
        BOT_COLOR_SUCCESS,
    )
    e.add_field(name=f"{EMOJI['categories']}  Categorias", value=f"**{categories}**", inline=True)
    e.add_field(name=f"{EMOJI['channels']}  Canais",       value=f"**{channels}**",   inline=True)
    e.add_field(name=f"{EMOJI['crown']}  Cargos",          value=f"**{roles}**",      inline=True)
    e.add_field(name=f"{EMOJI['data']}  Tempo",            value=f"**{elapsed:.1f}s**", inline=True)
    e.add_field(
        name=f"{EMOJI['star']}  Dica",
        value="Use `/restaurar` para recuperar este backup quando precisar.",
        inline=False,
    )
    return e


# ── Server Preview ────────────────────────────────────────────────────────────

def server_preview_embed(structure: dict) -> discord.Embed:
    server_name = structure.get("server_name", "Novo Servidor")
    description = structure.get("description", "")
    theme       = structure.get("theme", "Personalizado")
    categories  = structure.get("categories", [])
    roles       = structure.get("roles", [])
    total_ch    = sum(len(c.get("channels", [])) for c in categories)
    quality     = structure.get("quality_score", 85)
    eta         = structure.get("eta_seconds", 30)
    stars       = "⭐" * min(5, quality // 20)

    e = discord.Embed(
        title=f"{EMOJI['rocket']}  Prévia — {server_name}",
        description=(
            f"> {description}\n\u200b"
        ),
        color=0x5865F2,
        timestamp=datetime.datetime.utcnow(),
    )
    e.set_thumbnail(url=THUMBNAIL_URL)
    e.set_footer(text=FOOTER_TEXT, icon_url=THUMBNAIL_URL)

    e.add_field(
        name=f"{EMOJI['setting']}  Informações",
        value=(
            f"**Tema:** {theme}\n"
            f"**Qualidade:** {quality}/100 {stars}\n"
            f"**Tempo estimado:** ~{eta}s"
        ),
        inline=True,
    )
    e.add_field(
        name=f"{EMOJI['data']}  Estrutura",
        value=(
            f"**Categorias:** {len(categories)}\n"
            f"**Canais:** {total_ch}\n"
            f"**Cargos:** {len(roles)}"
        ),
        inline=True,
    )

    if categories:
        cat_lines = []
        for c in categories[:8]:
            ch_count = len(c.get("channels", []))
            cat_lines.append(f"{EMOJI['categories']} **{c['name']}** — {ch_count} canal(is)")
        if len(categories) > 8:
            cat_lines.append(f"*... e mais {len(categories)-8} categorias*")
        e.add_field(
            name=f"{EMOJI['channels']}  Categorias",
            value="\n".join(cat_lines),
            inline=False,
        )

    if roles:
        roles_text = "  ".join(f"`{r['name']}`" for r in roles[:12])
        if len(roles) > 12:
            roles_text += f" *+{len(roles)-12}*"
        e.add_field(
            name=f"{EMOJI['crown']}  Cargos",
            value=roles_text,
            inline=False,
        )

    return e


# ── Servidor Criado ───────────────────────────────────────────────────────────

def server_created_embed(guild: discord.Guild, elapsed: float) -> discord.Embed:
    e = discord.Embed(
        title=f"{EMOJI['rocket']}  Servidor Criado com Sucesso!",
        description=(
            f"**{guild.name}** foi completamente configurado pelo **Shard App** com IA!\n\u200b"
        ),
        color=BOT_COLOR_SUCCESS,
        timestamp=datetime.datetime.utcnow(),
    )
    if guild.icon:
        e.set_thumbnail(url=guild.icon.url)
    else:
        e.set_thumbnail(url=THUMBNAIL_URL)
    e.set_footer(text=FOOTER_TEXT, icon_url=THUMBNAIL_URL)

    e.add_field(name=f"{EMOJI['channels']}  Canais",  value=f"**{len(guild.channels)}**", inline=True)
    e.add_field(name=f"{EMOJI['crown']}  Cargos",     value=f"**{len(guild.roles)}**",   inline=True)
    e.add_field(name=f"{EMOJI['data']}  Tempo",        value=f"**{elapsed:.1f}s**",       inline=True)
    e.add_field(
        name=f"{EMOJI['star']}  Próximos Passos",
        value=(
            f"{EMOJI['categories']} Use `/backup` para salvar esta estrutura\n"
            f"{EMOJI['setting']} Use `/logs configurar` para ativar logs `🥉`\n"
            f"{EMOJI['new_member']} Use `/autorole configurar` para auto role `🥉`"
        ),
        inline=False,
    )
    return e


# ── Owner ─────────────────────────────────────────────────────────────────────

def owner_only_embed() -> discord.Embed:
    return _base(
        f"{EMOJI['crown']}  Acesso Negado",
        (
            "Este comando é exclusivo do **desenvolvedor do Shard App**.\n"
            "Não está disponível para outros usuários."
        ),
        BOT_COLOR_ERROR,
    )


# ── UserInfo ──────────────────────────────────────────────────────────────────

def userinfo_embed(member: discord.Member) -> discord.Embed:
    color = member.color if member.color.value else BOT_COLOR
    e = discord.Embed(
        title=f"{EMOJI['member']}  {member.display_name}",
        color=color,
        timestamp=datetime.datetime.utcnow(),
    )
    e.set_author(name=str(member), icon_url=member.display_avatar.url)
    e.set_thumbnail(url=member.display_avatar.url)
    e.set_footer(text=FOOTER_TEXT, icon_url=THUMBNAIL_URL)

    badges = []
    if member.bot:                         badges.append("🤖 Bot")
    if member.public_flags.staff:          badges.append("🛡️ Staff Discord")
    if member.public_flags.partner:        badges.append("🤝 Parceiro")
    if member.public_flags.hypesquad:      badges.append("🏠 HypeSquad")
    if member.public_flags.bug_hunter:     badges.append("🐛 Bug Hunter")
    if member.public_flags.early_supporter:badges.append("⭐ Early Supporter")

    id_line = (
        f"**ID:** `{member.id}`\n"
        f"**Nome:** {member.mention}"
    )
    if badges:
        id_line += f"\n**Badges:** {' · '.join(badges)}"

    e.add_field(
        name=f"{EMOJI['name']}  Identificação",
        value=id_line,
        inline=False,
    )
    e.add_field(
        name=f"📅  Conta Criada",
        value=(
            f"<t:{int(member.created_at.timestamp())}:F>\n"
            f"<t:{int(member.created_at.timestamp())}:R>"
        ),
        inline=True,
    )
    if member.joined_at:
        e.add_field(
            name=f"{EMOJI['new_member']}  Entrou no Servidor",
            value=(
                f"<t:{int(member.joined_at.timestamp())}:F>\n"
                f"<t:{int(member.joined_at.timestamp())}:R>"
            ),
            inline=True,
        )
    if member.premium_since:
        e.add_field(
            name=f"{EMOJI['nitro']}  Nitro Booster",
            value=f"<t:{int(member.premium_since.timestamp())}:R>",
            inline=True,
        )
    if member.roles[1:]:
        roles_sorted = sorted(member.roles[1:], key=lambda r: r.position, reverse=True)
        roles_str = " ".join(r.mention for r in roles_sorted[:10])
        if len(member.roles) - 1 > 10:
            roles_str += f" *(+{len(member.roles)-11})*"
        e.add_field(
            name=f"{EMOJI['crown']}  Cargos ({len(member.roles)-1})",
            value=roles_str,
            inline=False,
        )
    if member.top_role and not member.top_role.is_default():
        e.add_field(
            name=f"{EMOJI['star']}  Cargo Principal",
            value=member.top_role.mention,
            inline=True,
        )
    return e


# ── ServerInfo ────────────────────────────────────────────────────────────────

def serverinfo_embed(guild: discord.Guild) -> discord.Embed:
    owner = guild.owner
    total     = guild.member_count or 0
    bots      = sum(1 for m in guild.members if m.bot)
    humans    = total - bots
    text_ch   = len(guild.text_channels)
    voice_ch  = len(guild.voice_channels)
    cats      = len(guild.categories)
    emojis    = len(guild.emojis)
    verif     = str(guild.verification_level).replace("_", " ").title()

    e = discord.Embed(
        title=f"ℹ️  {guild.name}",
        description=guild.description or "",
        color=BOT_COLOR,
        timestamp=datetime.datetime.utcnow(),
    )
    if guild.icon:
        e.set_thumbnail(url=guild.icon.url)
    if guild.banner:
        e.set_image(url=guild.banner.url)
    e.set_footer(text=FOOTER_TEXT, icon_url=THUMBNAIL_URL)

    # Bloco geral (sem label separado — vai na description se vazia)
    e.add_field(
        name=f"{EMOJI['name']}  Geral",
        value=(
            f"**ID:** `{guild.id}`\n"
            f"**Dono:** {owner.mention if owner else '?'}\n"
            f"**Criado em:** <t:{int(guild.created_at.timestamp())}:D>\n"
            f"**Verificação:** {verif}"
        ),
        inline=False,
    )
    e.add_field(
        name=f"{EMOJI['people']}  Membros",
        value=(
            f"**Total:** {total}\n"
            f"**Humanos:** {humans}\n"
            f"**Online:** ~0\n"
            f"**Bots:** {bots}"
        ),
        inline=True,
    )
    e.add_field(
        name=f"{EMOJI['channels']}  Canais",
        value=(
            f"**Texto:** {text_ch}\n"
            f"**Voz:** {voice_ch}\n"
            f"**Categorias:** {cats}"
        ),
        inline=True,
    )
    e.add_field(
        name=f"{EMOJI['setting']}  Extras",
        value=(
            f"**Cargos:** {len(guild.roles)}\n"
            f"**Emojis:** {emojis}\n"
            f"**Boosts:** {guild.premium_subscription_count} (Tier {guild.premium_tier})"
        ),
        inline=True,
    )
    return e


# ── Help ──────────────────────────────────────────────────────────────────────

def help_embed(guild_count: int = 0) -> discord.Embed:
    e = _base(
        f"{EMOJI['bot']}  Shard App — Central de Ajuda",
        (
            "O bot mais poderoso para **criar e gerenciar** servidores Discord "
            "com **Inteligência Artificial**.\n"
            "Selecione uma **categoria** no menu abaixo para ver os comandos.\n\u200b"
        ),
    )
    e.add_field(
        name=f"{EMOJI['data']}  Estatísticas",
        value=(
            f"**Comandos:** 25 disponíveis\n"
            f"**Servidores:** {guild_count}\n"
            f"**Powered by:** Groq AI"
        ),
        inline=True,
    )
    e.add_field(
        name=f"{EMOJI['crown']}  Planos",
        value=(
            "🆓 Gratuito\n"
            "🥉 Bronze Shard\n"
            "💚 Esmeralda Shard\n"
            "💎 Diamante Shard"
        ),
        inline=True,
    )
    e.add_field(
        name=f"{EMOJI['star_link']}  Links",
        value=f"[Servidor Oficial]({SERVIDOR_OFICIAL_URL}) — Suporte e Premium",
        inline=False,
    )
    return e


def help_category_embed(category: str) -> discord.Embed:
    """Retorna embed de uma categoria específica do /ajuda."""
    CATS: dict[str, dict] = {
        "basic": {
            "title": f"{EMOJI['bot']}  Comandos Básicos",
            "description": "Comandos gerais disponíveis para **todos** os usuários.\n\u200b",
            "color": BOT_COLOR,
            "commands": [
                ("🏓 `/ping`",            "Latência e status do bot",             "🆓"),
                ("❓ `/ajuda`",           "Esta central de ajuda",                "🆓"),
                ("👤 `/perfil`",          "Seu perfil, plano e estatísticas",     "🆓"),
                ("💎 `/plans`",           "Todos os planos Premium",              "🆓"),
                ("🔍 `/userinfo`",        "Informações de um usuário",            "🆓"),
                ("🏠 `/serverinfo`",      "Informações completas do servidor",    "🆓"),
            ],
        },
        "creation": {
            "title": f"{EMOJI['categories']}  Criação com IA",
            "description": "Crie servidores completos usando **Inteligência Artificial**.\n\u200b",
            "color": 0x5865F2,
            "commands": [
                ("🚀 `/servidor criar`",  "Servidor completo gerado por IA",      "🆓"),
                ("📋 `/templates`",       "10 templates prontos de servidor",     "🆓"),
                ("📁 `/categoria`",       "Nova categoria criada por IA",         "🆓"),
                ("📢 `/canal`",           "Novo canal configurado por IA",        "🆓"),
                ("🎭 `/cargos`",          "Cargos hierárquicos via IA",           "🆓"),
            ],
        },
        "admin": {
            "title": f"{EMOJI['setting']}  Administração",
            "description": "Ferramentas para **gerenciar** e personalizar seu servidor.\n\u200b",
            "color": BOT_COLOR_BRONZE,
            "commands": [
                ("📋 `/logs configurar`",     "Define canal de logs",              "🥉"),
                ("🎭 `/autorole configurar`",  "Cargo automático p/ novos membros", "🥉"),
                ("📝 `/embed`",               "Cria embed personalizada",          "🥉"),
                ("🛡️ `/proteger`",            "Ativa Anti-Raid no servidor",       "💚"),
                ("🎨 `/aparencia`",           "Personalização visual completa",    "💎"),
                ("🗑️ `/excluir`",            "Remove canais ou cargos",           "🆓"),
            ],
        },
        "mod": {
            "title": f"{EMOJI['shield']}  Moderação",
            "description": "Mantenha seu servidor **seguro** e organizado.\n\u200b",
            "color": BOT_COLOR_ERROR,
            "commands": [
                ("🔨 `/ban`",   "Bane permanentemente um membro",           "🆓"),
                ("👢 `/kick`",  "Expulsa um membro do servidor",            "🆓"),
                ("🧹 `/limpar`","Remove até 100 mensagens de uma vez",      "🆓"),
            ],
        },
        "security": {
            "title": f"{EMOJI['super_shield']}  Backup & Segurança",
            "description": "Salve e restaure a **estrutura completa** do seu servidor.\n\u200b",
            "color": BOT_COLOR_EMERALD,
            "commands": [
                ("🗄️ `/backup`",    "Cria backup completo do servidor",     "🆓"),
                ("♻️ `/restaurar`", "Restaura um backup salvo",              "🆓"),
            ],
        },
        "premium": {
            "title": f"{EMOJI['crown']}  Planos Premium",
            "description": "Desbloqueie a IA mais poderosa e mais criações diárias.\n\u200b",
            "color": BOT_COLOR_DIAMOND,
            "commands": [
                ("🆓 Gratuito",             "3 criações/dia · IA padrão",                "—"),
                ("🥉 Bronze — R$15",        "5 criações/dia · Logs · AutoRole · Embed",  "—"),
                ("💚 Esmeralda — R$25",     "10 criações/dia · Anti-Raid · IA avançada", "—"),
                ("💎 Diamante — R$39,90",   "∞ Ilimitado · IA Premium · Aparência",      "—"),
            ],
            "note": f"Adquira em nosso [Servidor Oficial]({SERVIDOR_OFICIAL_URL})",
        },
    }

    data = CATS.get(category, CATS["basic"])
    e = discord.Embed(
        title=data["title"],
        description=data["description"],
        color=data.get("color", BOT_COLOR),
        timestamp=datetime.datetime.utcnow(),
    )
    e.set_thumbnail(url=THUMBNAIL_URL)
    e.set_footer(text=FOOTER_TEXT, icon_url=THUMBNAIL_URL)

    cmds = data.get("commands", [])
    if cmds:
        lines = "\n".join(
            f"{cmd}  —  {desc}  `{badge}`"
            for cmd, desc, badge in cmds
        )
        e.add_field(name=f"{EMOJI['pencil']}  Comandos", value=lines, inline=False)

    if "note" in data:
        e.add_field(
            name=f"{EMOJI['star_link']}  Comprar",
            value=f"{data['note']}",
            inline=False,
        )

    return e
