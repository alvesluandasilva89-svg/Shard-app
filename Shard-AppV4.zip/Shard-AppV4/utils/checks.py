"""
Shard App — Verificações e Guards
Funções de checagem de permissão, plano e ownership.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import discord
from discord import app_commands

from config.settings import BOT_OWNER_ID, PLAN_HIERARCHY, PLANS

if TYPE_CHECKING:
    from database.manager import DatabaseManager


async def get_user_plan(db: "DatabaseManager", user_id: int) -> str:
    """Retorna o plano atual do usuário."""
    data = await db.get_premium(user_id)
    return data.get("plan", "free")


def plan_meets_requirement(user_plan: str, required_plan: str) -> bool:
    """Verifica se o plano do usuário atende ao requisito mínimo."""
    try:
        user_idx = PLAN_HIERARCHY.index(user_plan)
        req_idx  = PLAN_HIERARCHY.index(required_plan)
        return user_idx >= req_idx
    except ValueError:
        return False


def is_owner(user_id: int) -> bool:
    """Verifica se o usuário é o dono do bot."""
    return user_id == BOT_OWNER_ID


async def check_daily_limit(
    db: "DatabaseManager",
    user_id: int,
    plan: str,
) -> tuple[bool, int, int]:
    """
    Verifica se o usuário pode ainda criar um servidor hoje.
    Retorna (pode_criar, usado, limite).
    """
    limit = PLANS[plan]["daily_limit"]
    used  = await db.get_daily_usage(user_id)
    if limit == 0:          # 0 = ilimitado (plano Diamond)
        return True, used, limit
    return used < limit, used, limit
