"""
Shard App — Event Handlers
Gerencia todos os eventos do Discord (on_guild_join, on_member_join, logs, proteção).
"""

from __future__ import annotations

import asyncio
import datetime
import logging
from typing import TYPE_CHECKING

import discord
from discord.ext import commands

from config.settings import EMOJI, SERVIDOR_OFICIAL_URL, FOOTER_TEXT, THUMBNAIL_URL

if TYPE_CHECKING:
    from main import ShardBot

logger = logging.getLogger("shard.events")


class EventHandlers(commands.Cog):
    """Cog responsável por todos os eventos do bot."""

    def __init__(self, bot: "ShardBot") -> None:
        self.bot = bot
        # Controle anti-raid: {guild_id: [timestamps]}
        self._join_tracker: dict[int, list[float]] = {}

    # ── Guild Join ────────────────────────────────────────────────────────────

    @commands.Cog.listener()
    async def on_guild_join(self, guild: discord.Guild) -> None:
        """Enviado quando o bot é adicionado a um servidor."""
        logger.info("Bot adicionado ao servidor: %s (%d)", guild.name, guild.id)

        # Encontrar o usuário que adicionou o bot
        owner = guild.owner
        if owner is None:
            return

        await asyncio.sleep(1)  # aguardar a inicialização do guild

        # Enviar DM ao dono do servidor
        embed = discord.Embed(
            title=f"🎉  Obrigado por adicionar o Shard App!",
            description=(
                "Obrigado por confiar no nosso projeto.\n\n"
                f"Utilize `/ajuda` para conhecer todos os comandos disponíveis.\n\n"
                f"Com `/servidor criar`, você poderá gerar um servidor completo "
                f"utilizando **Inteligência Artificial**.\n\n"
                f"Para suporte, novidades e compra dos planos Premium, acesse nosso servidor oficial:\n"
                f"**{SERVIDOR_OFICIAL_URL}**\n\n"
                "Esperamos que você tenha uma excelente experiência utilizando o **Shard App**!"
            ),
            color=0x00BFFF,
        )
        embed.set_thumbnail(url=THUMBNAIL_URL)
        embed.set_footer(text=FOOTER_TEXT)

        dm_view = discord.ui.View(timeout=None)
        dm_view.add_item(
            discord.ui.Button(
                label=f"{EMOJI['rocket']}  Servidor Oficial",
                style=discord.ButtonStyle.link,
                url=SERVIDOR_OFICIAL_URL,
            )
        )

        try:
            await owner.send(embed=embed, view=dm_view)
        except (discord.Forbidden, discord.HTTPException):
            logger.debug("Não foi possível enviar DM ao dono do servidor %s", guild.name)

        # Registrar dono no banco
        if self.bot.db:
            await self.bot.db.ensure_user(owner.id, str(owner))

    # ── Member Join ───────────────────────────────────────────────────────────

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member) -> None:
        """Disparado quando um membro entra no servidor."""
        guild = member.guild

        if not self.bot.db:
            return

        # Registrar no banco
        await self.bot.db.ensure_user(member.id, str(member))

        # Auto Role
        autorole_data = await self.bot.db.get_autorole(guild.id)
        if autorole_data and autorole_data.get("enabled"):
            role_id = autorole_data.get("role_id")
            if role_id:
                role = guild.get_role(role_id)
                if role and role < guild.me.top_role:
                    try:
                        await member.add_roles(role, reason="Shard App — Auto Role")
                        logger.debug("Auto Role aplicado: %s → %s", member.name, role.name)
                    except discord.HTTPException as e:
                        logger.warning("Falha ao aplicar Auto Role: %s", e)

        # Mensagem de boas-vindas (se configurada)
        channel_id = autorole_data.get("channel_id") if autorole_data else None
        message = autorole_data.get("message") if autorole_data else None

        if channel_id and message:
            channel = guild.get_channel(channel_id)
            if channel and isinstance(channel, discord.TextChannel):
                try:
                    msg = message.replace("{user}", member.mention).replace(
                        "{server}", guild.name
                    ).replace("{count}", str(guild.member_count))
                    await channel.send(msg)
                except discord.HTTPException:
                    pass

        # Anti-Raid: detectar entrada em massa
        prot = await self.bot.db.get_protection(guild.id)
        if prot and prot.get("anti_raid"):
            await self._check_raid(guild, member, prot)

        # Log de entrada
        await self._send_log(guild, "member_join", f"**{member}** ({member.id}) entrou no servidor.")

    # ── Member Remove ─────────────────────────────────────────────────────────

    @commands.Cog.listener()
    async def on_member_remove(self, member: discord.Member) -> None:
        guild = member.guild
        await self._send_log(guild, "member_leave", f"**{member}** ({member.id}) saiu do servidor.")

    # ── Guild Channel Events ──────────────────────────────────────────────────

    @commands.Cog.listener()
    async def on_guild_channel_create(self, channel: discord.abc.GuildChannel) -> None:
        guild = channel.guild

        # Proteção
        prot = await self.bot.db.get_protection(guild.id) if self.bot.db else None
        if prot and prot.get("anti_channel_create"):
            # Verificar se não foi o próprio bot criando
            async for entry in guild.audit_logs(limit=1, action=discord.AuditLogAction.channel_create):
                if entry.user and entry.user.id != self.bot.user.id:
                    alert_ch = guild.get_channel(prot.get("alert_channel_id", 0))
                    if alert_ch and isinstance(alert_ch, discord.TextChannel):
                        embed = discord.Embed(
                            title=f"{EMOJI['super_shield']}  Alerta de Proteção",
                            description=(
                                f"Canal criado por **{entry.user}** detectado.\n"
                                f"Canal: `{channel.name}` ({channel.type})"
                            ),
                            color=0xE74C3C,
                        )
                        embed.set_footer(text=FOOTER_TEXT)
                        try:
                            await alert_ch.send(embed=embed)
                        except Exception:
                            pass

        await self._send_log(guild, "channel_create", f"Canal `{channel.name}` criado.")

    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel: discord.abc.GuildChannel) -> None:
        guild = channel.guild

        prot = await self.bot.db.get_protection(guild.id) if self.bot.db else None
        if prot and prot.get("anti_channel_delete"):
            async for entry in guild.audit_logs(limit=1, action=discord.AuditLogAction.channel_delete):
                if entry.user and entry.user.id != self.bot.user.id:
                    alert_ch = guild.get_channel(prot.get("alert_channel_id", 0))
                    if alert_ch and isinstance(alert_ch, discord.TextChannel):
                        embed = discord.Embed(
                            title=f"{EMOJI['super_shield']}  Alerta de Proteção",
                            description=(
                                f"Canal deletado por **{entry.user}**.\n"
                                f"Canal: `{channel.name}`"
                            ),
                            color=0xE74C3C,
                        )
                        embed.set_footer(text=FOOTER_TEXT)
                        try:
                            await alert_ch.send(embed=embed)
                        except Exception:
                            pass

        await self._send_log(guild, "channel_delete", f"Canal `{channel.name}` excluído.")

    # ── Member Update ─────────────────────────────────────────────────────────

    @commands.Cog.listener()
    async def on_member_update(
        self, before: discord.Member, after: discord.Member
    ) -> None:
        guild = after.guild

        # Log de mudança de cargo
        if before.roles != after.roles:
            added   = [r for r in after.roles if r not in before.roles]
            removed = [r for r in before.roles if r not in after.roles]
            if added:
                await self._send_log(
                    guild, "role_change",
                    f"**{after}** recebeu o cargo {added[0].mention}."
                )
            if removed:
                await self._send_log(
                    guild, "role_change",
                    f"**{after}** perdeu o cargo {removed[0].mention}."
                )

        # Log de mudança de apelido
        if before.nick != after.nick:
            await self._send_log(
                guild, "nick_change",
                f"**{after}** mudou de apelido: `{before.nick}` → `{after.nick}`."
            )

    # ── Anti-Raid ─────────────────────────────────────────────────────────────

    async def _check_raid(
        self,
        guild: discord.Guild,
        member: discord.Member,
        prot: dict,
    ) -> None:
        """Detecta possível raid (5+ entradas em 10 segundos)."""
        now = datetime.datetime.utcnow().timestamp()
        guild_tracker = self._join_tracker.setdefault(guild.id, [])

        # Adicionar timestamp atual e limpar antigos (>10s)
        guild_tracker.append(now)
        self._join_tracker[guild.id] = [t for t in guild_tracker if now - t <= 10]

        if len(self._join_tracker[guild.id]) >= 5:
            logger.warning("Possível raid detectado no servidor %s (%d)", guild.name, guild.id)

            alert_ch = guild.get_channel(prot.get("alert_channel_id", 0))
            if alert_ch and isinstance(alert_ch, discord.TextChannel):
                embed = discord.Embed(
                    title=f"{EMOJI['super_shield']}  Possível Raid Detectado!",
                    description=(
                        f"**{len(self._join_tracker[guild.id])}** membros entraram nos últimos 10 segundos.\n"
                        "Verifique os novos membros e tome as medidas necessárias."
                    ),
                    color=0xE74C3C,
                    timestamp=datetime.datetime.utcnow(),
                )
                embed.set_footer(text=FOOTER_TEXT)
                try:
                    await alert_ch.send(embed=embed)
                except Exception:
                    pass

    # ── Sistema de Logs ───────────────────────────────────────────────────────

    async def _send_log(self, guild: discord.Guild, log_type: str, message: str) -> None:
        """Envia uma mensagem de log no canal configurado."""
        if not self.bot.db:
            return

        settings = await self.bot.db.get_log_settings(guild.id)
        if not settings:
            return

        # Verificar se este tipo de log está ativo
        type_map = {
            "member_join":    "log_member_join",
            "member_leave":   "log_member_leave",
            "channel_create": "log_channel_create",
            "channel_delete": "log_channel_delete",
            "role_change":    "log_role_change",
            "nick_change":    "log_nick_change",
            "ban":            "log_ban",
            "kick":           "log_kick",
            "clear":          "log_clear",
            "commands":       "log_commands",
        }

        col_name = type_map.get(log_type)
        if col_name and not settings.get(col_name, True):
            return

        log_channel_id = settings.get("log_channel_id")
        if not log_channel_id:
            return

        channel = guild.get_channel(log_channel_id)
        if not channel or not isinstance(channel, discord.TextChannel):
            return

        color_map = {
            "member_join":    0x2ECC71,
            "member_leave":   0xE74C3C,
            "channel_create": 0x3498DB,
            "channel_delete": 0xE74C3C,
            "role_change":    0x9B59B6,
            "nick_change":    0xF39C12,
            "ban":            0xE74C3C,
            "kick":           0xE67E22,
            "clear":          0x95A5A6,
            "commands":       0x3498DB,
        }

        embed = discord.Embed(
            description=message,
            color=color_map.get(log_type, 0x00BFFF),
            timestamp=datetime.datetime.utcnow(),
        )
        embed.set_footer(text=f"Shard App — Log | {log_type}")

        try:
            await channel.send(embed=embed)
        except discord.HTTPException:
            pass


async def setup(bot: "ShardBot") -> None:
    await bot.add_cog(EventHandlers(bot))
