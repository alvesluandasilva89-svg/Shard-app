"""
Shard App — Configurações Globais
Centraliza todas as constantes, emojis, cores e planos do bot.
"""

from __future__ import annotations
import os
from dotenv import load_dotenv

load_dotenv()

# ─── Credenciais ──────────────────────────────────────────────────────────────
TOKEN: str = os.getenv("BOT_TOKEN", "")
GROQ_API_KEY: str = os.getenv("GROQ_API_KEY", "")
ID_SERVIDOR_OFICIAL: int = int(os.getenv("ID_SERVIDOR_OFICIAL", "0"))
BOT_OWNER_ID: int = int(os.getenv("BOT_OWNER_ID", "0"))
BOT_OWNER_USERNAME: str = os.getenv("BOT_OWNER_USERNAME", "imbroxavelhahaahahahahah")

# ─── Identidade Visual ────────────────────────────────────────────────────────
BOT_NAME = "Shard App"
BOT_COLOR = 0x00BFFF          # Azul Ciano
BOT_COLOR_SUCCESS = 0x2ECC71  # Verde
BOT_COLOR_ERROR = 0xE74C3C    # Vermelho
BOT_COLOR_WARNING = 0xF39C12  # Amarelo
BOT_COLOR_BRONZE = 0xCD7F32
BOT_COLOR_EMERALD = 0x50C878
BOT_COLOR_DIAMOND = 0xB9F2FF

THUMBNAIL_URL = "https://i.ibb.co/8nMttsRX/6fa3f30915ff9c68cefe6f35cf07c080.jpg"
SERVIDOR_OFICIAL_URL = "https://discord.gg/ktfvKrGyrT"
FOOTER_TEXT = "Shard App • Sua solução completa para servidores Discord"

# ─── Emojis Personalizados ────────────────────────────────────────────────────
EMOJI = {
    "1000":         "<:1000_7:1516127198346612776>",
    "bot_badge":    "<:Bot:1516127097213550694>",
    "nitro":        "<:DiscordNitro:1516127291434860585>",
    "member":       "<:Member:1516127093141016748>",
    "partner":      "<:Partner:1516127108722720860>",
    "announce":     "<:announcements:1516127131212714025>",
    "announce2":    "<:announcements_2:1516127227593494623>",
    "anxiety":      "<:anxiety3:1516127207448252486>",
    "ban":          "<:ban_hammer:1516127295981617373>",
    "bot":          "<:bot:1516127124388315288>",
    "bot_dev":      "<:bot_developer:1516127266051063920>",
    "botik":        "<:botik:1516127232454688828>",
    "categories":   "<:categories:1516127237374476492>",
    "channels":     "<:channels:1516127271155531806>",
    "clear":        "<:clear:1516127216944156763>",
    "crown":        "<:crown:1516127259629715588>",
    "data":         "<:data_transfer:1516127147192750200>",
    "discord":      "<:discord:1516127311995338769>",
    "gift":         "<:gift:1516127187164729520>",
    "giveaway":     "<:giveaway:1516127156860747958>",
    "mention":      "<:mention:1516127301706842142>",
    "name":         "<:name_info:1516127323659702272>",
    "new_member":   "<:new_member:1516127284979826868>",
    "link":         "<:non_link:1516127150976139425>",
    "pencil":       "<:pencil2:1516127139911696524>",
    "people":       "<:people:1516127127248961556>",
    "questions":    "<:questions:1516127222224781492>",
    "region":       "<:region:1516127170831847436>",
    "rocket":       "<:rocket:1516127203199418378>",
    "rules":        "<:rules:1516127175110299699>",
    "screw":        "<:screw:1516127121129345166>",
    "shield":       "<:shieldn:1516127306207461627>",
    "setting":      "<:setting:1516127143602421780>",
    "shieldys":     "<:shieldys:1516127178839035936>",
    "something":    "<:something:1516127166595731477>",
    "star":         "<:star:1516127135562076263>",
    "star_link":    "<:star_link:1516127183163228227>",
    "star_mod":     "<:star_moderator:1516127328105926807>",
    "super_shield": "<:super_shield:1516127211919249499>",
    "telegram":     "<:telegram:1516127162414141531>",
}

# ─── Planos Premium ───────────────────────────────────────────────────────────
PLANS: dict[str, dict] = {
    "free": {
        "name": "Gratuito",
        "emoji": "🆓",
        "color": BOT_COLOR,
        "price": "Grátis",
        "daily_limit": 3,
        "badge": "⬜",
        "tagline": "O começo da jornada.",
        "subtitle": "Crie servidores básicos com IA e descubra o poder do Shard App.",
        "benefits": [
            "🆓 **3 criações** de servidor por dia",
            "📦 Backups **ilimitados** do servidor",
            "♻️ Restauração de backups próprios",
            "📋 Templates básicos prontos",
            "🤖 IA padrão integrada",
            "👤 Perfil e estatísticas pessoais",
        ],
    },
    "bronze": {
        "name": "Bronze Shard",
        "emoji": "🥉",
        "color": BOT_COLOR_BRONZE,
        "price": "R$ 15,00/mês",
        "daily_limit": 5,
        "badge": "🥉",
        "tagline": "Mais poder, mais controle.",
        "subtitle": "Ferramentas avançadas para quem leva o Discord a sério.",
        "benefits": [
            "🥉 Tudo do plano **Gratuito**",
            "⚡ **5 criações** por dia com IA aprimorada",
            "📋 `/logs configurar` — Logs automáticos",
            "🎭 `/autorole configurar` — Cargo automático",
            "📝 `/embed` — Crie embeds personalizadas",
            "📌 Templates **Premium** exclusivos",
            "⭐ Perfil **Bronze** exclusivo",
        ],
    },
    "emerald": {
        "name": "Esmeralda Shard",
        "emoji": "💚",
        "color": BOT_COLOR_EMERALD,
        "price": "R$ 25,00/mês",
        "daily_limit": 10,
        "badge": "💚",
        "tagline": "Proteção e inteligência elevadas.",
        "subtitle": "IA mais inteligente e segurança avançada para seu servidor.",
        "benefits": [
            "💚 Tudo do plano **Bronze Shard**",
            "🚀 **10 criações** por dia com IA avançada",
            "🛡️ `/proteger` — Anti-Raid e auditoria",
            "🧠 IA **llama-3.3-70b** de alta performance",
            "📊 Estatísticas avançadas do servidor",
            "🌟 Templates **Esmeralda** exclusivos",
            "💚 Perfil **Esmeralda** exclusivo",
        ],
    },
    "diamond": {
        "name": "Diamante Shard",
        "emoji": "💎",
        "color": BOT_COLOR_DIAMOND,
        "price": "R$ 39,90/mês",
        "daily_limit": 0,
        "badge": "💎",
        "tagline": "O plano definitivo — poder absoluto!",
        "subtitle": "Ilimitado, personalizado e com suporte VIP.",
        "benefits": [
            "🚀 Tudo do plano **Esmeralda Shard**",
            "</> `/aparencia` — Personaliza apelido, cor e boas-vindas",
            "👑 Suporte **prioritário VIP** direto com a equipe",
            "↩️ Acesso antecipado a novos recursos",
            "👑 Badge **Diamante Shard** exclusivo",
            "🎁 Participação em sorteios exclusivos",
        ],
    },
}

PLAN_HIERARCHY = ["free", "bronze", "emerald", "diamond"]

# Mapeamento de plano → groq model
PLAN_GROQ_MODEL: dict[str, str] = {
    "free":    "llama-3.1-8b-instant",
    "bronze":  "llama-3.1-8b-instant",
    "emerald": "llama-3.3-70b-versatile",
    "diamond": "llama-3.3-70b-versatile",
}

# ─── Cooldowns (segundos) ─────────────────────────────────────────────────────
COOLDOWN_SERVER_CREATE = 30
COOLDOWN_BACKUP = 10
COOLDOWN_MODERATION = 5

# ─── Templates ────────────────────────────────────────────────────────────────
TEMPLATES: dict[str, dict] = {
    "games": {
        "name": "🎮 Jogos",
        "description": "Servidor completo para comunidade gamer com canais de cada jogo, VoIP, torneios e suporte.",
        "premium": False,
        "prompt": (
            "Crie um servidor Discord para comunidade gamer com: "
            "categorias para informações, jogos populares (Free Fire, Minecraft, Valorant, CS2, League of Legends), "
            "canais de voz para partidas, area de torneios, sistema de cargos por jogo, "
            "canal de clips e highlights, regras anti-toxicidade, suporte e staff."
        ),
    },
    "anime": {
        "name": "🎌 Animes",
        "description": "Comunidade de animes com canais por temporada, spoilers e fan-arts.",
        "premium": False,
        "prompt": (
            "Crie um servidor Discord para fãs de animes com: "
            "categorias por gênero (shounen, romance, isekai, terror), canais de discussão de temporadas atuais, "
            "canal de spoilers com aviso, galeria de fan-art, recomendações, "
            "cargos por anime favorito, canal de notícias e lançamentos."
        ),
    },
    "football": {
        "name": "⚽ Futebol",
        "description": "Servidor para torcidas, bolões e discussões de futebol.",
        "premium": False,
        "prompt": (
            "Crie um servidor Discord para futebol com: "
            "categorias por liga (Brasileirão, Champions, Premier League, La Liga), "
            "canais de discussão por clube, bolão de resultados, transmissões ao vivo, "
            "cargos por time do coração, canal de notícias e transferências."
        ),
    },
    "programming": {
        "name": "💻 Programação",
        "description": "Comunidade tech com canais por linguagem, projetos e vagas.",
        "premium": True,
        "prompt": (
            "Crie um servidor Discord de programação com: "
            "canais por linguagem (Python, JavaScript, Java, C++, Go, Rust), "
            "categorias para frontend, backend, mobile, DevOps, banco de dados, "
            "canal de dúvidas e ajuda, showcase de projetos, vagas de emprego, "
            "recursos e tutoriais, cargos por nível (júnior, pleno, sênior)."
        ),
    },
    "store": {
        "name": "🛒 Loja",
        "description": "Servidor de vendas online com catálogo, suporte e pagamentos.",
        "premium": True,
        "prompt": (
            "Crie um servidor Discord de loja online com: "
            "categorias para catálogo de produtos, pedidos, pagamentos, suporte ao cliente, "
            "canal de novidades e promoções, canal de avaliações, "
            "cargos de cliente VIP, staff de vendas, área de afiliados."
        ),
    },
    "music": {
        "name": "🎵 Música",
        "description": "Comunidade musical com canais por gênero, produções e playlists.",
        "premium": True,
        "prompt": (
            "Crie um servidor Discord de música com: "
            "categorias por gênero (rap, eletrônica, rock, sertanejo, pop), "
            "canal de beats e produções, compartilhamento de playlists, "
            "descobertas musicais, cargos por gênero favorito, canal ao vivo."
        ),
    },
    "streaming": {
        "name": "📺 Streaming",
        "description": "Servidor para criadores de conteúdo com canais de live e clipes.",
        "premium": True,
        "prompt": (
            "Crie um servidor Discord de streaming/criadores de conteúdo com: "
            "categorias para lives, clipes, bastidores, parceiros, "
            "canal de avisos de live, galeria de clipes, collab entre criadores, "
            "cargos de subscriber, moderador, parceiro."
        ),
    },
    "studies": {
        "name": "📚 Estudos",
        "description": "Servidor educacional com canais por matéria, PDFs e grupos de estudo.",
        "premium": False,
        "prompt": (
            "Crie um servidor Discord de estudos com: "
            "categorias por área (exatas, humanas, ciências, idiomas, concursos), "
            "canais de grupos de estudo, compartilhamento de materiais, "
            "maratonas de estudos, dúvidas por matéria, motivação e metas."
        ),
    },
    "community": {
        "name": "👥 Comunidade",
        "description": "Servidor geral de comunidade com interação, eventos e suporte.",
        "premium": False,
        "prompt": (
            "Crie um servidor Discord de comunidade geral com: "
            "categorias de informações, bate-papo, hobbies, entretenimento, "
            "sistema de boas-vindas, canal de apresentações, eventos, sorteios, "
            "cargos de atividade, moderação e administração."
        ),
    },
    "events": {
        "name": "🏆 Eventos",
        "description": "Servidor para organização de eventos, campeonatos e torneios.",
        "premium": True,
        "prompt": (
            "Crie um servidor Discord de eventos com: "
            "categorias para inscrições, regulamento, resultados, premiações, "
            "canais por fase/rodada, tabela de classificação, sala VIP para finalistas, "
            "cargos de participante, árbitro, campeão."
        ),
    },
}
