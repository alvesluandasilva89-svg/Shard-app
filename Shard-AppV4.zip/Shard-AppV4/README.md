# 🤖 Shard App

> **Sua solução completa para servidores Discord**

O Shard App é um bot Premium para Discord especializado em criação automática de servidores utilizando Inteligência Artificial, gerenciamento avançado, backup, proteção e muito mais.

---

## 📋 Índice

- [Instalação](#instalação)
- [Configuração](#configuração)
- [Hospedagem](#hospedagem)
- [Comandos](#comandos)
- [Planos](#planos)
- [Estrutura do Projeto](#estrutura)
- [FAQ](#faq)

---

## ⚡ Instalação

### Pré-requisitos

- Python 3.11 ou superior
- pip atualizado

### Passos

```bash
# 1. Clone ou extraia o projeto
cd Shard-App

# 2. Instale as dependências
pip install -r requirements.txt

# 3. Configure o .env
cp .env.example .env
# Edite o arquivo .env com suas credenciais

# 4. Inicie o bot
python main.py
```

---

## ⚙️ Configuração

Edite o arquivo `.env` com suas informações:

```env
# Token do Bot Discord
# Obtenha em: https://discord.com/developers/applications
TOKEN=seu_token_aqui

# Chave da API Groq (Inteligência Artificial)
# Obtenha em: https://console.groq.com
GROQ_API_KEY=sua_chave_groq_aqui

# ID do Servidor Oficial do Shard App
ID_SERVIDOR_OFICIAL=1234567890

# Seu ID de usuário no Discord (somente números)
# Para obter: Configurações > Avançado > Modo desenvolvedor > Clique direito no seu nome > Copiar ID
BOT_OWNER_ID=seu_id_discord_aqui

# Seu nome de usuário Discord
BOT_OWNER_USERNAME=seu_usuario_aqui
```

### Como obter o Token do Bot

1. Acesse https://discord.com/developers/applications
2. Crie um novo aplicativo
3. Vá em **Bot** → **Reset Token** → Copie o token
4. Em **Privileged Gateway Intents**, ative:
   - ✅ Server Members Intent
   - ✅ Message Content Intent
5. Em **OAuth2 > URL Generator**, selecione:
   - Scopes: `bot`, `applications.commands`
   - Permissões: `Administrator` (recomendado)
6. Use o link gerado para adicionar o bot ao servidor

### Como obter a chave Groq

1. Acesse https://console.groq.com
2. Crie uma conta gratuita
3. Vá em **API Keys** → **Create API Key**
4. Copie a chave gerada

---

## 🖥️ Hospedagem

### Replit

1. Crie uma conta em https://replit.com
2. Crie um novo Repl → selecione **Python**
3. Faça upload dos arquivos do projeto
4. Configure os **Secrets** (equivalente ao .env):
   - `TOKEN` = seu token
   - `GROQ_API_KEY` = sua chave Groq
   - `ID_SERVIDOR_OFICIAL` = ID do servidor
   - `BOT_OWNER_ID` = seu ID Discord
5. No arquivo `main.py` já está configurado para ler as variáveis de ambiente
6. Clique em **Run**
7. Para manter online 24/7, use o **UptimeRobot** para fazer ping no Repl

### Shard Cloud / VPS Linux

```bash
# Instalar Python 3.11 (Ubuntu/Debian)
sudo apt update
sudo apt install python3.11 python3.11-pip python3.11-venv -y

# Criar ambiente virtual (recomendado)
python3.11 -m venv venv
source venv/bin/activate

# Instalar dependências
pip install -r requirements.txt

# Configurar .env
nano .env
# (preencha suas credenciais)

# Rodar em background com screen
screen -S shard
python main.py
# Pressione Ctrl+A, depois D para desanexar

# Ou usar systemd (produção)
sudo nano /etc/systemd/system/shard.service
```

#### Arquivo systemd para VPS:

```ini
[Unit]
Description=Shard App Discord Bot
After=network.target

[Service]
Type=simple
User=seu_usuario
WorkingDirectory=/caminho/para/Shard-App
ExecStart=/caminho/para/venv/bin/python main.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl daemon-reload
sudo systemctl enable shard
sudo systemctl start shard
sudo systemctl status shard
```

---

## 📖 Comandos

### Básicos (Todos os usuários)

| Comando | Descrição |
|---|---|
| `/ping` | Verifica a latência do bot |
| `/ajuda` | Lista todos os comandos |
| `/perfil` | Seu perfil e estatísticas |
| `/plans` | Ver planos Premium |
| `/userinfo` | Informações de um usuário |
| `/serverinfo` | Informações do servidor |

### Criação

| Comando | Descrição | Plano |
|---|---|---|
| `/servidor criar` | Cria servidor completo com IA | Todos |
| `/templates` | Templates prontos de servidor | Todos |
| `/categoria` | Cria nova categoria com IA | Todos |
| `/canal` | Cria novo canal com IA | Todos |
| `/cargos` | Cria cargos com IA | Todos |

### Administração

| Comando | Descrição | Plano |
|---|---|---|
| `/logs configurar` | Configura canal de logs | 🥉 Bronze+ |
| `/autorole configurar` | Cargo automático para membros | 🥉 Bronze+ |
| `/embed` | Cria embed personalizada | 🥉 Bronze+ |
| `/proteger` | Ativa Anti-Raid e proteção | 💚 Esmeralda+ |
| `/aparencia` | Personaliza aparência | 💎 Diamante |
| `/excluir` | Exclui elementos do servidor | Todos |

### Segurança

| Comando | Descrição | Plano |
|---|---|---|
| `/backup` | Cria backup do servidor | Todos |
| `/restaurar` | Restaura um backup | Todos |

### Moderação

| Comando | Descrição |
|---|---|
| `/ban` | Bane um membro |
| `/kick` | Expulsa um membro |
| `/limpar` | Apaga mensagens |

### Desenvolvedor (Owner apenas)

| Comando | Descrição |
|---|---|
| `/dar_premium` | Concede plano Premium a usuário |
| `/tirar_premium` | Remove plano Premium |
| `/ver_premium` | Consulta Premium de usuário |

---

## 💎 Planos

| Plano | Preço | Criações/dia | Recursos extras |
|---|---|---|---|
| 🆓 Gratuito | Grátis | 3 | Básico |
| 🥉 Bronze Shard | R$ 15/mês | 5 | Logs, Auto Role, Embed |
| 💚 Esmeralda Shard | R$ 20/mês | 7 | Proteção, Anti-Raid |
| 💎 Diamante Shard | R$ 30/mês | 20 | IA Premium, Aparência |

> As compras são feitas no servidor oficial: https://discord.gg/ktfvKrGyrT

---

## 📁 Estrutura

```
Shard-App/
├── main.py                  # Entrada principal do bot
├── requirements.txt         # Dependências Python
├── README.md                # Esta documentação
├── .env.example             # Modelo de configuração
├── assets/                  # Arquivos de mídia
├── config/
│   └── settings.py          # Configurações globais, emojis, planos
├── database/
│   └── manager.py           # Gerenciador SQLite assíncrono
├── commands/
│   ├── basic.py             # /ping /ajuda /perfil /plans /userinfo /serverinfo
│   ├── server.py            # /servidor /templates /categoria /canal /cargos
│   ├── admin.py             # /logs /autorole /embed /aparencia /excluir /proteger
│   ├── backup.py            # /backup /restaurar
│   ├── moderation.py        # /ban /kick /limpar
│   └── owner.py             # /dar_premium /tirar_premium /ver_premium
├── views/
│   ├── premium_views.py     # Views do sistema Premium
│   ├── server_views.py      # Modais e views de criação
│   └── backup_views.py      # Views de backup e exclusão
├── events/
│   └── handlers.py          # on_guild_join, on_member_join, logs, proteção
├── services/
│   ├── ai_service.py        # Serviço de IA (Groq API)
│   └── backup_service.py    # Serviço de backup/restauração
├── models/
│   └── user.py              # Modelo de dados do usuário
├── utils/
│   ├── embeds.py            # Construtores de embeds
│   ├── checks.py            # Verificações de plano e permissão
│   └── helpers.py           # Funções utilitárias
├── ai/
│   └── groq_client.py       # Cliente HTTP assíncrono da Groq API
├── logs/                    # Arquivos de log
└── backups/                 # Pasta de backups (reserva)
```

---

## ❓ FAQ

**P: O bot não responde aos comandos slash.**
R: Aguarde até 1 hora para os comandos globais propagarem. Alternativamente, sincronize apenas no servidor de testes adicionando o guild_id no `tree.sync(guild=...)`.

**P: Erro "Token inválido".**
R: Verifique se o TOKEN no `.env` está correto e sem espaços extras.

**P: A IA não gera estruturas.**
R: Verifique se a `GROQ_API_KEY` está configurada e válida em https://console.groq.com.

**P: O bot não consegue criar canais/cargos.**
R: Certifique-se de que o bot possui permissão de **Administrador** ou ao menos **Gerenciar Canais** e **Gerenciar Cargos**. O cargo do bot deve estar no topo da hierarquia.

**P: Como faço para que os comandos do owner funcionem?**
R: Configure o `BOT_OWNER_ID` no `.env` com o seu ID numérico do Discord (não o nome de usuário).

**P: O banco de dados é criado automaticamente?**
R: Sim! Na primeira execução, todas as tabelas são criadas automaticamente em `database/shard.db`.

**P: Como hospedar no Replit sem o bot cair?**
R: Use o UptimeRobot (https://uptimerobot.com) para fazer ping periódico no URL do seu Repl e mantê-lo ativo.

---

## 📞 Suporte

- **Servidor Oficial:** https://discord.gg/ktfvKrGyrT
- **Compra de planos Premium:** Via servidor oficial

---

*Shard App • Sua solução completa para servidores Discord*
