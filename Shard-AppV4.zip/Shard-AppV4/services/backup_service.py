"""
Shard App — Backup Service
Salva e restaura estruturas completas de servidores Discord.
"""

from __future__ import annotations

import asyncio
import datetime
import logging
from typing import TYPE_CHECKING, Optional

import discord

from utils.helpers import safe_delete_channels, safe_delete_roles, color_from_hex, role_permissions_from_list

if TYPE_CHECKING:
    from database.manager import DatabaseManager

logger = logging.getLogger("shard.backup")


class BackupService:
    """Serviço de backup e restauração de servidores Discord."""

    def __init__(self, db: "DatabaseManager") -> None:
        self.db = db

    # ── Criar Backup ──────────────────────────────────────────────────────────

    async def create_backup(
        self,
        guild: discord.Guild,
        user_id: int,
        name: Optional[str] = None,
    ) -> dict:
        """
        Cria um backup completo da estrutura do servidor.
        Retorna um dicionário com metadados do backup.
        """
        start = datetime.datetime.utcnow()
        backup_name = name or f"Backup {guild.name} {start.strftime('%d/%m/%Y %H:%M')}"

        data = await self._snapshot_guild(guild)

        backup_id = await self.db.save_backup(
            user_id=user_id,
            guild_id=guild.id,
            name=backup_name,
            data=data,
        )

        elapsed = (datetime.datetime.utcnow() - start).total_seconds()
        logger.info(
            "Backup criado: id=%d guild=%d user=%d elapsed=%.1fs",
            backup_id, guild.id, user_id, elapsed,
        )

        return {
            "id": backup_id,
            "name": backup_name,
            "categories": len(data["categories"]),
            "channels": sum(len(c["channels"]) for c in data["categories"]),
            "roles": len(data["roles"]),
            "elapsed": elapsed,
        }

    async def _snapshot_guild(self, guild: discord.Guild) -> dict:
        """Captura a estrutura atual do servidor."""
        categories = []
        for cat in guild.categories:
            channels_data = []
            for ch in cat.channels:
                ch_data = _serialize_channel(ch)
                if ch_data:
                    channels_data.append(ch_data)
            categories.append({
                "name": cat.name,
                "position": cat.position,
                "channels": channels_data,
                "overwrites": _serialize_overwrites(cat.overwrites),
            })

        # Canais sem categoria
        no_cat_channels = []
        for ch in guild.channels:
            if ch.category is None and not isinstance(ch, discord.CategoryChannel):
                ch_data = _serialize_channel(ch)
                if ch_data:
                    no_cat_channels.append(ch_data)

        roles = []
        for role in guild.roles:
            if role.is_default() or role.managed:
                continue
            roles.append({
                "name": role.name,
                "color": str(role.color),
                "permissions": role.permissions.value,
                "hoist": role.hoist,
                "mentionable": role.mentionable,
                "position": role.position,
            })

        return {
            "server_name": guild.name,
            "categories": categories,
            "channels_no_cat": no_cat_channels,
            "roles": sorted(roles, key=lambda r: r["position"]),
            "description": guild.description or "",
            "snapshot_at": datetime.datetime.utcnow().isoformat(),
        }

    # ── Restaurar Backup ──────────────────────────────────────────────────────

    async def restore_backup(
        self,
        guild: discord.Guild,
        backup_data: dict,
        progress_callback=None,
    ) -> dict:
        """
        Restaura um backup em um servidor.
        progress_callback(step: str) é chamado a cada etapa para atualizar a UI.
        """
        start = datetime.datetime.utcnow()
        errors: list[str] = []
        bot_member = guild.me

        async def _progress(step: str) -> None:
            if progress_callback:
                try:
                    await progress_callback(step)
                except Exception:
                    pass

        # 1. Remover canais existentes
        await _progress("🗑️ Removendo canais existentes...")
        removed_ch, errs = await safe_delete_channels(guild, bot_member)
        errors.extend(errs)
        await asyncio.sleep(1)

        # 2. Remover cargos existentes
        await _progress("🗑️ Removendo cargos existentes...")
        removed_roles, errs = await safe_delete_roles(guild, bot_member)
        errors.extend(errs)
        await asyncio.sleep(1)

        # 3. Criar cargos
        await _progress("👑 Criando cargos...")
        role_map: dict[str, discord.Role] = {}
        for role_data in backup_data.get("roles", []):
            try:
                color = discord.Color(int(role_data.get("color", "0x000000").replace("#", "0x"), 16))
                perms = discord.Permissions(role_data.get("permissions", 0))
                role = await guild.create_role(
                    name=role_data["name"],
                    color=color,
                    permissions=perms,
                    hoist=role_data.get("hoist", False),
                    mentionable=role_data.get("mentionable", False),
                    reason="Shard App — Restauração de backup",
                )
                role_map[role_data["name"]] = role
                await asyncio.sleep(0.3)
            except discord.HTTPException as e:
                errors.append(f"Cargo {role_data['name']}: {e}")

        # 4. Criar categorias e canais
        await _progress("📂 Recriando categorias e canais...")
        for cat_data in backup_data.get("categories", []):
            try:
                category = await guild.create_category(
                    name=cat_data["name"],
                    reason="Shard App — Restauração de backup",
                )
                await asyncio.sleep(0.5)

                for ch_data in cat_data.get("channels", []):
                    await _create_channel(guild, category, ch_data, errors)
                    await asyncio.sleep(0.3)
            except discord.HTTPException as e:
                errors.append(f"Categoria {cat_data['name']}: {e}")

        elapsed = (datetime.datetime.utcnow() - start).total_seconds()
        logger.info(
            "Backup restaurado: guild=%d elapsed=%.1fs erros=%d",
            guild.id, elapsed, len(errors),
        )

        return {
            "elapsed": elapsed,
            "errors": errors,
            "categories_created": len(backup_data.get("categories", [])),
            "roles_created": len(role_map),
        }


# ── Helpers de Serialização ───────────────────────────────────────────────────

def _serialize_channel(ch: discord.abc.GuildChannel) -> Optional[dict]:
    """Serializa um canal para dict."""
    if isinstance(ch, discord.TextChannel):
        return {
            "name": ch.name,
            "type": "text",
            "topic": ch.topic or "",
            "nsfw": ch.nsfw,
            "slowmode": ch.slowmode_delay,
            "position": ch.position,
        }
    elif isinstance(ch, discord.VoiceChannel):
        return {
            "name": ch.name,
            "type": "voice",
            "bitrate": ch.bitrate,
            "user_limit": ch.user_limit,
            "position": ch.position,
        }
    elif isinstance(ch, discord.ForumChannel):
        return {
            "name": ch.name,
            "type": "forum",
            "topic": ch.topic or "",
            "position": ch.position,
        }
    elif isinstance(ch, discord.StageChannel):
        return {
            "name": ch.name,
            "type": "stage",
            "position": ch.position,
        }
    return None


def _serialize_overwrites(overwrites: dict) -> list:
    """Serializa as permissões de sobrescrita."""
    result = []
    for target, overwrite in overwrites.items():
        allow, deny = overwrite.pair()
        result.append({
            "target_id": target.id,
            "target_type": "role" if isinstance(target, discord.Role) else "member",
            "allow": allow.value,
            "deny": deny.value,
        })
    return result


async def _create_channel(
    guild: discord.Guild,
    category: discord.CategoryChannel,
    ch_data: dict,
    errors: list[str],
) -> None:
    """Cria um canal em uma categoria."""
    try:
        ch_type = ch_data.get("type", "text")
        if ch_type == "voice":
            await guild.create_voice_channel(
                name=ch_data["name"],
                category=category,
                bitrate=min(ch_data.get("bitrate", 64000), 96000),
                user_limit=ch_data.get("user_limit", 0),
                reason="Shard App — Restauração de backup",
            )
        elif ch_type == "forum":
            await guild.create_forum(
                name=ch_data["name"],
                category=category,
                topic=ch_data.get("topic", ""),
                reason="Shard App — Restauração de backup",
            )
        elif ch_type in ("text", "announcement"):
            await guild.create_text_channel(
                name=ch_data["name"],
                category=category,
                topic=ch_data.get("topic", ""),
                nsfw=ch_data.get("nsfw", False),
                slowmode_delay=ch_data.get("slowmode", 0),
                news=(ch_type == "announcement"),
                reason="Shard App — Restauração de backup",
            )
    except discord.HTTPException as e:
        errors.append(f"Canal {ch_data.get('name', '?')}: {e}")
