"""
Shard App — AI Service
Gera estruturas de servidor completas usando a Groq API.
"""

from __future__ import annotations

import json
import logging
from typing import Optional

from ai.groq_client import GroqClient
from config.settings import PLAN_GROQ_MODEL

logger = logging.getLogger("shard.ai_service")

SYSTEM_PROMPT = """
Você é um arquiteto especialista em servidores Discord. Sua função é gerar estruturas
completas de servidor Discord em formato JSON puro, sem texto adicional.

REGRAS OBRIGATÓRIAS:
1. Responda APENAS com JSON válido, sem markdown, sem explicações.
2. Crie uma estrutura realista, profissional e bem organizada.
3. Use nomes em português, adequados ao tema solicitado.
4. Cargos devem ter hierarquia clara (posição mais alta = mais poderoso).
5. Canais devem estar organizados em categorias lógicas.
6. Permissões devem ser coerentes com a função de cada cargo.

FORMATO OBRIGATÓRIO DO JSON:
{
  "server_name": "Nome do Servidor",
  "description": "Descrição curta do servidor",
  "theme": "Tema geral",
  "quality_score": 90,
  "eta_seconds": 45,
  "categories": [
    {
      "name": "INFORMAÇÕES",
      "position": 0,
      "channels": [
        {
          "name": "regras",
          "type": "text",
          "topic": "Regras do servidor",
          "nsfw": false,
          "position": 0,
          "slowmode": 0
        },
        {
          "name": "Sala de Voz",
          "type": "voice",
          "bitrate": 64000,
          "user_limit": 10,
          "position": 1
        }
      ]
    }
  ],
  "roles": [
    {
      "name": "Administrador",
      "color": "#FF0000",
      "position": 10,
      "hoist": true,
      "mentionable": false,
      "permissions": ["administrator"]
    }
  ],
  "rules": [
    "Seja respeitoso com todos os membros.",
    "Proibido spam e flood."
  ],
  "welcome_message": "Bem-vindo ao servidor! Leia as regras em #regras."
}

Tipos de canal válidos: "text", "voice", "forum", "announcement", "stage"
Permissões válidas: "send_messages", "read_messages", "manage_messages", 
"manage_channels", "manage_roles", "kick_members", "ban_members",
"administrator", "embed_links", "attach_files", "mention_everyone",
"connect", "speak", "mute_members", "deafen_members", "move_members",
"view_channel", "view_audit_log", "manage_guild"
"""


class AIService:
    """Serviço de inteligência artificial para geração de estruturas de servidor."""

    def __init__(self) -> None:
        self.client = GroqClient()

    async def close(self) -> None:
        await self.client.close()

    async def generate_server_structure(
        self,
        prompt: str,
        plan: str = "free",
    ) -> Optional[dict]:
        """
        Gera a estrutura completa de um servidor Discord a partir de um prompt.
        
        Args:
            prompt: Descrição do servidor desejado pelo usuário.
            plan: Plano do usuário (afeta o modelo utilizado).
        
        Returns:
            Dicionário com a estrutura do servidor ou None em caso de erro.
        """
        model = PLAN_GROQ_MODEL.get(plan, "llama-3.1-8b-instant")

        # Enriquecer o prompt baseado no plano
        detail_level = _get_detail_level(plan)

        user_prompt = (
            f"Crie um servidor Discord completo com o seguinte tema/descrição:\n\n"
            f"{prompt}\n\n"
            f"{detail_level}"
        )

        logger.info("Gerando estrutura de servidor | plano=%s modelo=%s", plan, model)

        structure = await self.client.generate_json(
            prompt=user_prompt,
            system=SYSTEM_PROMPT,
            model=model,
        )

        if not structure:
            logger.warning("IA não retornou estrutura válida para o prompt: %.100s", prompt)
            return _fallback_structure(prompt)

        # Garantir campos obrigatórios
        structure.setdefault("server_name", "Novo Servidor")
        structure.setdefault("description", prompt[:100])
        structure.setdefault("theme", "Personalizado")
        structure.setdefault("quality_score", 80)
        structure.setdefault("eta_seconds", 30)
        structure.setdefault("categories", [])
        structure.setdefault("roles", [])
        structure.setdefault("rules", [])
        structure.setdefault("welcome_message", "Bem-vindo!")

        logger.info(
            "Estrutura gerada: %d categorias, %d cargos",
            len(structure["categories"]),
            len(structure["roles"]),
        )
        return structure

    async def generate_roles(self, prompt: str, plan: str = "free") -> Optional[list[dict]]:
        """Gera cargos a partir de um prompt."""
        model = PLAN_GROQ_MODEL.get(plan, "llama-3.1-8b-instant")

        system = """
Você é um especialista em cargos Discord. Responda APENAS com JSON válido.
Formato: {"roles": [{"name": "Nome", "color": "#HEX", "permissions": ["perm1"], "hoist": true, "mentionable": false, "reason": "Motivo deste cargo"}]}
"""
        result = await self.client.generate_json(
            prompt=f"Crie cargos para: {prompt}",
            system=system,
            model=model,
        )
        if result and "roles" in result:
            return result["roles"]
        return None

    async def generate_category(self, prompt: str, plan: str = "free") -> Optional[dict]:
        """Gera uma categoria com canais a partir de um prompt."""
        model = PLAN_GROQ_MODEL.get(plan, "llama-3.1-8b-instant")

        system = """
Você cria categorias Discord. Responda APENAS com JSON válido.
Formato: {"name": "NOME CATEGORIA", "channels": [{"name": "canal", "type": "text", "topic": "desc"}]}
"""
        return await self.client.generate_json(
            prompt=f"Crie uma categoria Discord para: {prompt}",
            system=system,
            model=model,
        )

    async def generate_channel(self, prompt: str, plan: str = "free") -> Optional[dict]:
        """Gera configuração de canal a partir de um prompt."""
        model = PLAN_GROQ_MODEL.get(plan, "llama-3.1-8b-instant")

        system = """
Você cria canais Discord. Responda APENAS com JSON válido.
Formato: {"name": "nome-canal", "type": "text|voice|forum|announcement", "topic": "descrição", "slowmode": 0, "nsfw": false}
"""
        return await self.client.generate_json(
            prompt=f"Crie um canal Discord para: {prompt}",
            system=system,
            model=model,
        )


def _get_detail_level(plan: str) -> str:
    """Retorna instrução de nível de detalhe baseado no plano."""
    if plan == "diamond":
        return (
            "Crie um servidor EXTREMAMENTE COMPLETO e detalhado. "
            "Use no mínimo 8-12 categorias, 40-60 canais, 10-15 cargos com permissões detalhadas. "
            "Inclua canais de texto, voz, fóruns e anúncios. "
            "Crie regras completas e uma mensagem de boas-vindas elaborada."
        )
    elif plan == "emerald":
        return (
            "Crie um servidor bem completo. "
            "Use 6-10 categorias, 25-40 canais, 8-12 cargos. "
            "Inclua variedade de tipos de canais."
        )
    elif plan == "bronze":
        return (
            "Crie um servidor completo. "
            "Use 5-8 categorias, 15-25 canais, 6-10 cargos."
        )
    else:
        return (
            "Crie um servidor funcional. "
            "Use 4-6 categorias, 10-18 canais, 4-7 cargos."
        )


def _fallback_structure(prompt: str) -> dict:
    """Estrutura fallback caso a IA falhe."""
    return {
        "server_name": "Novo Servidor",
        "description": prompt[:100],
        "theme": "Personalizado",
        "quality_score": 70,
        "eta_seconds": 20,
        "categories": [
            {
                "name": "INFORMAÇÕES",
                "position": 0,
                "channels": [
                    {"name": "regras", "type": "text", "topic": "Regras do servidor", "nsfw": False, "position": 0, "slowmode": 0},
                    {"name": "anúncios", "type": "announcement", "topic": "Novidades", "nsfw": False, "position": 1, "slowmode": 0},
                ],
            },
            {
                "name": "GERAL",
                "position": 1,
                "channels": [
                    {"name": "bate-papo", "type": "text", "topic": "Chat geral", "nsfw": False, "position": 0, "slowmode": 0},
                    {"name": "apresentações", "type": "text", "topic": "Apresente-se!", "nsfw": False, "position": 1, "slowmode": 30},
                    {"name": "Sala Geral", "type": "voice", "bitrate": 64000, "user_limit": 0, "position": 2},
                ],
            },
            {
                "name": "SUPORTE",
                "position": 2,
                "channels": [
                    {"name": "dúvidas", "type": "text", "topic": "Tire suas dúvidas aqui", "nsfw": False, "position": 0, "slowmode": 5},
                    {"name": "tickets", "type": "text", "topic": "Abra um ticket para suporte", "nsfw": False, "position": 1, "slowmode": 0},
                ],
            },
        ],
        "roles": [
            {"name": "Fundador", "color": "#FFD700", "position": 5, "hoist": True, "mentionable": False, "permissions": ["administrator"]},
            {"name": "Administrador", "color": "#FF4500", "position": 4, "hoist": True, "mentionable": True, "permissions": ["administrator"]},
            {"name": "Moderador", "color": "#1E90FF", "position": 3, "hoist": True, "mentionable": True, "permissions": ["kick_members", "ban_members", "manage_messages"]},
            {"name": "Membro", "color": "#2ECC71", "position": 1, "hoist": False, "mentionable": False, "permissions": ["send_messages", "read_messages", "connect", "speak"]},
        ],
        "rules": [
            "Seja respeitoso com todos os membros.",
            "Proibido spam, flood e conteúdo NSFW fora dos canais permitidos.",
            "Siga as Diretrizes da Comunidade do Discord.",
            "Não faça publicidade sem autorização da equipe.",
            "Respeite as decisões da moderação.",
        ],
        "welcome_message": "Bem-vindo ao servidor! Leia as regras e aproveite a comunidade.",
    }
