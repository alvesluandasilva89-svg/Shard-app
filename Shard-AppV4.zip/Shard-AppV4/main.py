"""
Shard App — Entry Point
Bot principal: inicialização, carregamento de Cogs e sincronização de comandos.
"""

from __future__ import annotations

import asyncio
import logging
import os
import sys
from pathlib import Path

import discord
from discord.ext import commands
from dotenv import load_dotenv

# ── Carregar .env antes de qualquer import interno ────────────────────────────
load_dotenv()

from config.settings import TOKEN, GROQ_API_KEY, BOT_COLOR, FOOTER_TEXT
from database.manager import DatabaseManager
from services.ai_service import AIService
from services.backup_service import BackupService

# ── Configurar logging ────────────────────────────────────────────────────────

def _setup_logging() -> None:
    """Configura o sistema de logs com saída em arquivo e console."""
    logs_dir = Path("logs")
    logs_dir.mkdir(exist_ok=True)

    fmt = "%(asctime)s [%(levelname)-8s] %(name)s: %(message)s"
    datefmt = "%Y-%m-%d %H:%M:%S"

    logging.basicConfig(
        level=logging.INFO,
        format=fmt,
        datefmt=datefmt,
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler(logs_dir / "shard.log", encoding="utf-8"),
        ],
    )

    # Silenciar logs muito verbosos de libs externas
    logging.getLogger("discord").setLevel(logging.WARNING)
    logging.getLogger("discord.http").setLevel(logging.ERROR)
    logging.getLogger("aiohttp").setLevel(logging.WARNING)


_setup_logging()
logger = logging.getLogger("shard.main")

# ── Cogs a carregar ───────────────────────────────────────────────────────────

COGS = [
    "commands.basic",
    "commands.server",
    "commands.admin",
    "commands.backup",
    "commands.moderation",
    "commands.owner",
    "events.handlers",
]


# ── Bot Principal ─────────────────────────────────────────────────────────────

class ShardBot(commands.Bot):
    """Bot principal do Shard App."""

    def __init__(self) -> None:
        intents = discord.Intents.default()
        intents.members = True
        intents.message_content = True

        super().__init__(
            command_prefix="!",        # prefix não usado — apenas slash commands
            intents=intents,
            help_command=None,         # desativado — usamos /ajuda
            case_insensitive=True,
        )

        # Serviços injetados no on_ready
        self.db: DatabaseManager = DatabaseManager()
        self.ai_service: AIService = AIService()
        self.backup_service: BackupService = BackupService(self.db)

    # ── Setup ─────────────────────────────────────────────────────────────────

    async def setup_hook(self) -> None:
        """Chamado antes do bot conectar — carrega cogs e conecta ao banco."""
        # Conectar banco de dados
        await self.db.connect()
        logger.info("Banco de dados inicializado.")

        # Carregar Cogs
        for cog in COGS:
            try:
                await self.load_extension(cog)
                logger.info("Cog carregado: %s", cog)
            except Exception as e:
                logger.error("Falha ao carregar cog %s: %s", cog, e)
                # Não impede o bot de iniciar

        # Sincronizar Slash Commands globalmente
        try:
            synced = await self.tree.sync()
            logger.info("Slash commands sincronizados: %d comandos", len(synced))
        except Exception as e:
            logger.error("Falha ao sincronizar slash commands: %s", e)

    # ── Events ────────────────────────────────────────────────────────────────

    async def on_ready(self) -> None:
        """Disparado quando o bot está pronto."""
        logger.info(
            "Shard App iniciado | %s (%d) | Servidores: %d",
            self.user,
            self.user.id,
            len(self.guilds),
        )

        # Status do bot
        activity = discord.Activity(
            type=discord.ActivityType.watching,
            name="/ajuda | Shard App",
        )
        await self.change_presence(
            status=discord.Status.online,
            activity=activity,
        )

    async def on_application_command_error(
        self,
        interaction: discord.Interaction,
        error: discord.app_commands.AppCommandError,
    ) -> None:
        """Tratamento global de erros em slash commands."""
        logger.error(
            "Erro no comando /%s por %s: %s",
            interaction.command.name if interaction.command else "?",
            interaction.user,
            error,
        )

        from utils.embeds import error_embed
        embed = error_embed(
            "Ocorreu um Erro",
            "Algo deu errado ao executar este comando. Tente novamente em alguns instantes.",
        )

        try:
            if interaction.response.is_done():
                await interaction.followup.send(embed=embed, ephemeral=True)
            else:
                await interaction.response.send_message(embed=embed, ephemeral=True)
        except Exception:
            pass

    async def on_error(self, event_method: str, /, *args, **kwargs) -> None:
        """Tratamento global de erros em eventos."""
        logger.exception("Erro no evento %s", event_method)

    async def close(self) -> None:
        """Limpeza ao fechar o bot."""
        logger.info("Encerrando Shard App...")
        await self.ai_service.close()
        await self.db.close()
        await super().close()


# ── Entry Point ───────────────────────────────────────────────────────────────

async def main() -> None:
    """Ponto de entrada assíncrono."""
    # Validação mínima de configuração
    if not TOKEN:
        logger.critical("TOKEN não definido no .env! O bot não pode iniciar.")
        sys.exit(1)

    if not GROQ_API_KEY:
        logger.warning("GROQ_API_KEY não definida. Recursos de IA estarão limitados.")

    bot = ShardBot()

    try:
        async with bot:
            await bot.start(TOKEN)
    except discord.LoginFailure:
        logger.critical("Token inválido! Verifique o TOKEN no arquivo .env.")
        sys.exit(1)
    except KeyboardInterrupt:
        logger.info("Encerrado pelo usuário.")
    except Exception as e:
        logger.critical("Erro fatal: %s", e)
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())
