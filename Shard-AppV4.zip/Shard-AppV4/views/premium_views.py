"""
Shard App — Views de Premium e Ajuda
Painéis, botões e menus relacionados ao sistema Premium e Help.
"""

from __future__ import annotations

import discord

from config.settings import SERVIDOR_OFICIAL_URL, PLANS
from utils.embeds import (
    premium_required_embed, daily_limit_embed, plan_detail_embed,
    help_embed, help_category_embed,
)


# ─── Botões de link reutilizáveis ─────────────────────────────────────────────

def _buy_button() -> discord.ui.Button:
    return discord.ui.Button(
        label="🛒  Adquirir Premium",
        style=discord.ButtonStyle.link,
        url=SERVIDOR_OFICIAL_URL,
        row=1,
    )

def _server_button() -> discord.ui.Button:
    return discord.ui.Button(
        label="🌐  Servidor Oficial",
        style=discord.ButtonStyle.link,
        url=SERVIDOR_OFICIAL_URL,
    )


# ─── Help View ────────────────────────────────────────────────────────────────

class HelpView(discord.ui.View):
    """View principal do /ajuda com select de categorias."""

    def __init__(self, guild_count: int = 0) -> None:
        super().__init__(timeout=180)
        self.guild_count = guild_count
        self.add_item(_server_button())

    @discord.ui.select(
        placeholder="📂  Selecione uma categoria...",
        min_values=1,
        max_values=1,
        options=[
            discord.SelectOption(
                label="Básicos",
                value="basic",
                description="Ping, perfil, userinfo e mais",
                emoji="🤖",
            ),
            discord.SelectOption(
                label="Criação com IA",
                value="creation",
                description="Criar servidores, canais e cargos",
                emoji="🏗️",
            ),
            discord.SelectOption(
                label="Administração",
                value="admin",
                description="Logs, AutoRole, Embed e proteção",
                emoji="⚙️",
            ),
            discord.SelectOption(
                label="Moderação",
                value="mod",
                description="Ban, kick e limpar mensagens",
                emoji="🛡️",
            ),
            discord.SelectOption(
                label="Backup & Segurança",
                value="security",
                description="Backup e restauração de servidores",
                emoji="🔒",
            ),
            discord.SelectOption(
                label="Planos Premium",
                value="premium",
                description="Benefícios e preços dos planos",
                emoji="💎",
            ),
        ],
        row=0,
    )
    async def category_select(
        self, interaction: discord.Interaction, select: discord.ui.Select
    ) -> None:
        cat = select.values[0]
        embed = help_category_embed(cat)
        await interaction.response.edit_message(embed=embed, view=self)

    @discord.ui.button(
        label="🏠  Início",
        style=discord.ButtonStyle.secondary,
        row=1,
    )
    async def home(
        self, interaction: discord.Interaction, button: discord.ui.Button
    ) -> None:
        embed = help_embed(self.guild_count)
        await interaction.response.edit_message(embed=embed, view=self)

    @discord.ui.button(
        label="💎  Ver Planos",
        style=discord.ButtonStyle.primary,
        row=1,
    )
    async def ver_planos(
        self, interaction: discord.Interaction, button: discord.ui.Button
    ) -> None:
        view = PlansView()
        await interaction.response.send_message(
            embed=plan_detail_embed("free"), view=view, ephemeral=True
        )


# ─── Plans View ───────────────────────────────────────────────────────────────

class PlansView(discord.ui.View):
    """View com navegação entre planos — estilo screenshot premium."""

    def __init__(self, current_plan: str = "free") -> None:
        super().__init__(timeout=180)
        self.current_plan = current_plan
        # Link de compra sempre visível na row 1
        self.add_item(_buy_button())

    # ── Botões de navegação de plano ──────────────────────────────────────────

    @discord.ui.button(
        label="FREE  Grátis",
        style=discord.ButtonStyle.secondary,
        row=0,
    )
    async def btn_free(
        self, interaction: discord.Interaction, button: discord.ui.Button
    ) -> None:
        self._highlight("free")
        await interaction.response.edit_message(
            embed=plan_detail_embed("free"), view=self
        )

    @discord.ui.button(
        label="⭐  Bronze Shard",
        style=discord.ButtonStyle.secondary,
        row=0,
    )
    async def btn_bronze(
        self, interaction: discord.Interaction, button: discord.ui.Button
    ) -> None:
        self._highlight("bronze")
        await interaction.response.edit_message(
            embed=plan_detail_embed("bronze"), view=self
        )

    @discord.ui.button(
        label="💚  Esmeralda Shard",
        style=discord.ButtonStyle.success,
        row=0,
    )
    async def btn_emerald(
        self, interaction: discord.Interaction, button: discord.ui.Button
    ) -> None:
        self._highlight("emerald")
        await interaction.response.edit_message(
            embed=plan_detail_embed("emerald"), view=self
        )

    @discord.ui.button(
        label="💎  Diamante Shard",
        style=discord.ButtonStyle.primary,
        row=0,
    )
    async def btn_diamond(
        self, interaction: discord.Interaction, button: discord.ui.Button
    ) -> None:
        self._highlight("diamond")
        await interaction.response.edit_message(
            embed=plan_detail_embed("diamond"), view=self
        )

    def _highlight(self, selected: str) -> None:
        """Marca o plano selecionado visualmente (estilo diferente)."""
        styles = {
            "free":    discord.ButtonStyle.secondary,
            "bronze":  discord.ButtonStyle.secondary,
            "emerald": discord.ButtonStyle.success,
            "diamond": discord.ButtonStyle.primary,
        }
        btn_map = {
            "free":    self.btn_free,
            "bronze":  self.btn_bronze,
            "emerald": self.btn_emerald,
            "diamond": self.btn_diamond,
        }
        for key, btn in btn_map.items():
            btn.style = discord.ButtonStyle.danger if key == selected else styles[key]
        self.current_plan = selected


# ─── Premium Required View ────────────────────────────────────────────────────

class PremiumRequiredView(discord.ui.View):
    """Exibida quando o usuário tenta acessar recurso Premium sem o plano."""

    def __init__(self) -> None:
        super().__init__(timeout=120)
        self.add_item(
            discord.ui.Button(
                label="💎  Comprar Premium",
                style=discord.ButtonStyle.link,
                url=SERVIDOR_OFICIAL_URL,
            )
        )
        self.add_item(_server_button())


# ─── Profile View ─────────────────────────────────────────────────────────────

class ProfileView(discord.ui.View):
    """View do perfil do usuário."""

    def __init__(self) -> None:
        super().__init__(timeout=120)
        self.add_item(_server_button())

    @discord.ui.button(
        label="💎  Ver Planos",
        style=discord.ButtonStyle.primary,
        row=0,
    )
    async def show_plans(
        self, interaction: discord.Interaction, button: discord.ui.Button
    ) -> None:
        await interaction.response.send_message(
            embed=plan_detail_embed("free"), view=PlansView(), ephemeral=True
        )

    @discord.ui.button(
        label="🔄  Atualizar",
        style=discord.ButtonStyle.secondary,
        row=0,
    )
    async def refresh(
        self, interaction: discord.Interaction, button: discord.ui.Button
    ) -> None:
        """Atualiza o perfil com dados mais recentes."""
        from utils.embeds import profile_embed
        from utils.helpers import days_remaining

        bot = interaction.client
        user = interaction.user

        try:
            await bot.db.ensure_user(user.id, str(user))  # type: ignore
            premium_data  = await bot.db.get_premium(user.id)  # type: ignore
            daily_used    = await bot.db.get_daily_usage(user.id)  # type: ignore
            backup_count  = await bot.db.get_backup_count(user.id)  # type: ignore
            total_servers = await bot.db.get_server_creation_count(user.id)  # type: ignore
            dr = days_remaining(premium_data.get("expires_at"))

            member = (
                interaction.guild.get_member(user.id)
                if interaction.guild else None
            ) or user

            embed = profile_embed(
                user=member,
                premium_data=premium_data,
                daily_used=daily_used,
                backup_count=backup_count,
                total_servers=total_servers,
                days_remaining=dr,
            )
            await interaction.response.edit_message(embed=embed, view=self)
        except Exception:
            await interaction.response.defer()


# ─── Daily Limit View ─────────────────────────────────────────────────────────

class DailyLimitView(discord.ui.View):
    """Exibida quando o usuário atingiu o limite diário."""

    def __init__(self) -> None:
        super().__init__(timeout=120)
        self.add_item(
            discord.ui.Button(
                label="⬆️  Fazer Upgrade",
                style=discord.ButtonStyle.link,
                url=SERVIDOR_OFICIAL_URL,
            )
        )
        self.add_item(_server_button())
