"""
Shard App — Views de Criação de Servidor
Modais, botões e seleções do fluxo de criação de servidor.
"""

from __future__ import annotations

import asyncio
import datetime
import logging
from typing import TYPE_CHECKING, Optional

import discord

from config.settings import EMOJI, SERVIDOR_OFICIAL_URL, TEMPLATES
from utils.embeds import (
    server_preview_embed, server_created_embed, loading_embed, error_embed, success_embed
)
from utils.helpers import safe_send_dm

if TYPE_CHECKING:
    from services.ai_service import AIService
    from services.backup_service import BackupService
    from database.manager import DatabaseManager

logger = logging.getLogger("shard.views.server")


# ── Modal de Criação ──────────────────────────────────────────────────────────

class ServerCreateModal(discord.ui.Modal, title="Criar Servidor"):
    """Modal onde o usuário descreve o servidor desejado."""

    description_input: discord.ui.TextInput = discord.ui.TextInput(
        label="Descreva seu servidor",
        placeholder="Ex: comunidade gamer com Free Fire, Minecraft, torneios e cargos por jogo",
        style=discord.TextStyle.paragraph,
        required=True,
        min_length=10,
        max_length=1000,
    )

    def __init__(
        self,
        ai_service: "AIService",
        backup_service: "BackupService",
        db: "DatabaseManager",
        user_plan: str,
    ) -> None:
        super().__init__(timeout=300)
        self.ai_service = ai_service
        self.backup_service = backup_service
        self.db = db
        self.user_plan = user_plan

    async def on_submit(self, interaction: discord.Interaction) -> None:
        """Processa o prompt após o usuário submeter o modal."""
        await interaction.response.defer(ephemeral=True, thinking=True)

        prompt = self.description_input.value
        guild = interaction.guild
        user = interaction.user

        if not guild:
            await interaction.followup.send(
                embed=error_embed("Erro", "Este comando só pode ser usado em servidores."),
                ephemeral=True,
            )
            return

        # Etapa 3: Mostrar loading e processar com IA
        loading_steps = [
            f"{EMOJI['data']} Lendo seu prompt...",
            f"{EMOJI['bot']} Interpretando com IA...",
            f"{EMOJI['categories']} Criando categorias...",
            f"{EMOJI['channels']} Criando canais...",
            f"{EMOJI['crown']} Criando cargos...",
            f"{EMOJI['shield']} Configurando permissões...",
            f"{EMOJI['rules']} Criando regras...",
            f"{EMOJI['star']} Finalizando projeto...",
        ]

        msg = await interaction.followup.send(
            embed=loading_embed(loading_steps[0]),
            ephemeral=True,
        )

        async def update_loading(step_idx: int) -> None:
            if step_idx < len(loading_steps):
                try:
                    await msg.edit(embed=loading_embed(loading_steps[step_idx]))
                    await asyncio.sleep(0.8)
                except Exception:
                    pass

        for i in range(1, 4):
            await update_loading(i)

        # Chamar IA
        structure = await self.ai_service.generate_server_structure(
            prompt=prompt,
            plan=self.user_plan,
        )

        for i in range(4, 8):
            await update_loading(i)

        if not structure:
            await msg.edit(
                embed=error_embed(
                    "Erro na IA",
                    "Não foi possível gerar a estrutura do servidor. Tente novamente com uma descrição diferente.",
                ),
                view=None,
            )
            return

        # Etapa 4: Mostrar prévia
        preview_embed = server_preview_embed(structure)
        preview_view = ServerPreviewView(
            structure=structure,
            prompt=prompt,
            ai_service=self.ai_service,
            backup_service=self.backup_service,
            db=self.db,
            user_plan=self.user_plan,
        )

        await msg.edit(embed=preview_embed, view=preview_view)


# ── View de Prévia ────────────────────────────────────────────────────────────

class ServerPreviewView(discord.ui.View):
    """Botões da prévia de criação do servidor."""

    def __init__(
        self,
        structure: dict,
        prompt: str,
        ai_service: "AIService",
        backup_service: "BackupService",
        db: "DatabaseManager",
        user_plan: str,
    ) -> None:
        super().__init__(timeout=300)
        self.structure = structure
        self.prompt = prompt
        self.ai_service = ai_service
        self.backup_service = backup_service
        self.db = db
        self.user_plan = user_plan

    @discord.ui.button(
        label="✅ Criar Servidor",
        style=discord.ButtonStyle.success,
        row=0,
    )
    async def confirm(
        self, interaction: discord.Interaction, button: discord.ui.Button
    ) -> None:
        """Inicia a criação do servidor após confirmação."""
        await interaction.response.defer()
        await self._create_server(interaction)

    @discord.ui.button(
        label="✏️ Editar Prompt",
        style=discord.ButtonStyle.secondary,
        row=0,
    )
    async def edit_prompt(
        self, interaction: discord.Interaction, button: discord.ui.Button
    ) -> None:
        """Reabre o modal para editar o prompt."""
        from views.server_views import ServerCreateModal
        modal = ServerCreateModal(
            ai_service=self.ai_service,
            backup_service=self.backup_service,
            db=self.db,
            user_plan=self.user_plan,
        )
        modal.description_input.default = self.prompt[:999]
        await interaction.response.send_modal(modal)

    @discord.ui.button(
        label="❌ Cancelar",
        style=discord.ButtonStyle.danger,
        row=0,
    )
    async def cancel(
        self, interaction: discord.Interaction, button: discord.ui.Button
    ) -> None:
        await interaction.response.edit_message(
            embed=error_embed("Cancelado", "A criação do servidor foi cancelada."),
            view=None,
        )

    async def _create_server(self, interaction: discord.Interaction) -> None:
        """Executa a criação do servidor etapa por etapa."""
        guild = interaction.guild
        user = interaction.user

        if not guild:
            return

        start = datetime.datetime.utcnow()
        bot_member = guild.me
        structure = self.structure
        errors: list[str] = []

        async def progress(step: str) -> None:
            try:
                await interaction.edit_original_response(
                    embed=loading_embed(step), view=None
                )
            except Exception:
                pass

        await progress(f"{EMOJI['clear']} Limpando estrutura existente...")

        # Remover canais
        from utils.helpers import safe_delete_channels, safe_delete_roles
        _, ch_errors = await safe_delete_channels(guild, bot_member)
        errors.extend(ch_errors)
        await asyncio.sleep(1)

        # Remover cargos
        _, role_errors = await safe_delete_roles(guild, bot_member)
        errors.extend(role_errors)
        await asyncio.sleep(1)

        await progress(f"{EMOJI['crown']} Criando cargos...")

        # Criar cargos
        roles_data = structure.get("roles", [])
        roles_sorted = sorted(roles_data, key=lambda r: r.get("position", 0))
        for role_data in roles_sorted:
            try:
                hex_color = role_data.get("color", "#000000").replace("#", "")
                color = discord.Color(int(hex_color, 16)) if hex_color else discord.Color.default()
            except (ValueError, TypeError):
                color = discord.Color.default()

            perms_list = role_data.get("permissions", [])
            from utils.helpers import role_permissions_from_list
            perms = role_permissions_from_list(perms_list)

            try:
                await guild.create_role(
                    name=role_data.get("name", "Cargo"),
                    color=color,
                    permissions=perms,
                    hoist=role_data.get("hoist", False),
                    mentionable=role_data.get("mentionable", False),
                    reason="Shard App — Criação por IA",
                )
                await asyncio.sleep(0.4)
            except discord.HTTPException as e:
                errors.append(f"Cargo {role_data.get('name', '?')}: {e}")

        await progress(f"{EMOJI['categories']} Criando categorias e canais...")

        # Criar categorias e canais
        rules_channel = None
        welcome_channel = None

        for cat_data in structure.get("categories", []):
            try:
                category = await guild.create_category(
                    name=cat_data.get("name", "Categoria"),
                    reason="Shard App — Criação por IA",
                )
                await asyncio.sleep(0.5)

                for ch_data in cat_data.get("channels", []):
                    ch = await _create_channel_from_data(guild, category, ch_data)
                    if ch:
                        name_lower = ch.name.lower()
                        if "regra" in name_lower and rules_channel is None:
                            rules_channel = ch
                        if any(w in name_lower for w in ["boas-vindas", "welcome", "bem-vindo"]) and welcome_channel is None:
                            welcome_channel = ch
                    await asyncio.sleep(0.3)
            except discord.HTTPException as e:
                errors.append(f"Categoria {cat_data.get('name', '?')}: {e}")

        # Enviar regras
        if rules_channel and isinstance(rules_channel, discord.TextChannel):
            await progress(f"{EMOJI['rules']} Enviando regras...")
            rules = structure.get("rules", [])
            if rules:
                rules_text = "\n".join(f"> **{i+1}.** {rule}" for i, rule in enumerate(rules))
                try:
                    embed = discord.Embed(
                        title=f"{EMOJI['rules']}  Regras do Servidor",
                        description=rules_text,
                        color=0x00BFFF,
                    )
                    embed.set_footer(text="Shard App • Sua solução completa para servidores Discord")
                    await rules_channel.send(embed=embed)
                except Exception:
                    pass

        # Enviar boas-vindas
        if welcome_channel and isinstance(welcome_channel, discord.TextChannel):
            welcome_msg = structure.get("welcome_message", "Bem-vindo!")
            try:
                embed = discord.Embed(
                    title=f"{EMOJI['new_member']}  Bem-vindo!",
                    description=welcome_msg,
                    color=0x00BFFF,
                )
                embed.set_footer(text="Shard App • Sua solução completa para servidores Discord")
                await welcome_channel.send(embed=embed)
            except Exception:
                pass

        # Registrar no banco
        elapsed = (datetime.datetime.utcnow() - start).total_seconds()
        await self.db.increment_daily_usage(user.id)
        await self.db.add_server_creation(
            user_id=user.id,
            guild_id=guild.id,
            prompt=self.prompt,
            plan=self.user_plan,
        )

        await progress(f"{EMOJI['star']} Finalizando...")
        await asyncio.sleep(1)

        # Mostrar resultado
        result_embed = server_created_embed(guild, elapsed)
        if errors:
            result_embed.add_field(
                name="⚠️ Avisos",
                value="\n".join(f"> {e}" for e in errors[:5]),
                inline=False,
            )

        await interaction.edit_original_response(embed=result_embed, view=None)

        # Etapa 6: DM ao usuário
        dm_embed = discord.Embed(
            title=f"{EMOJI['rocket']}  Servidor Criado com Sucesso!",
            description=(
                f"Seu servidor **{guild.name}** foi configurado pelo Shard App!\n\n"
                "Para alterar algo futuramente use `/servidor criar` ou `/restaurar`."
            ),
            color=0x00BFFF,
        )
        dm_embed.set_footer(text="Shard App • Sua solução completa para servidores Discord")
        dm_embed.set_thumbnail(url="https://i.ibb.co/8nMttsRX/6fa3f30915ff9c68cefe6f35cf07c080.jpg")

        dm_view = discord.ui.View(timeout=None)
        dm_view.add_item(
            discord.ui.Button(
                label="🌐  Servidor Oficial",
                style=discord.ButtonStyle.link,
                url=SERVIDOR_OFICIAL_URL,
            )
        )
        await safe_send_dm(user, embed=dm_embed, view=dm_view)

        logger.info(
            "Servidor criado: guild=%d user=%d elapsed=%.1fs erros=%d",
            guild.id, user.id, elapsed, len(errors),
        )


async def _create_channel_from_data(
    guild: discord.Guild,
    category: discord.CategoryChannel,
    ch_data: dict,
) -> Optional[discord.abc.GuildChannel]:
    """Cria um canal baseado nos dados da estrutura."""
    name = ch_data.get("name", "canal")
    ch_type = ch_data.get("type", "text")

    try:
        if ch_type == "voice":
            return await guild.create_voice_channel(
                name=name,
                category=category,
                bitrate=min(ch_data.get("bitrate", 64000), 96000),
                user_limit=ch_data.get("user_limit", 0),
                reason="Shard App — Criação por IA",
            )
        elif ch_type == "forum":
            return await guild.create_forum(
                name=name,
                category=category,
                topic=ch_data.get("topic", ""),
                reason="Shard App — Criação por IA",
            )
        elif ch_type == "announcement":
            return await guild.create_text_channel(
                name=name,
                category=category,
                topic=ch_data.get("topic", ""),
                news=True,
                reason="Shard App — Criação por IA",
            )
        else:
            return await guild.create_text_channel(
                name=name,
                category=category,
                topic=ch_data.get("topic", ""),
                nsfw=ch_data.get("nsfw", False),
                slowmode_delay=ch_data.get("slowmode", 0),
                reason="Shard App — Criação por IA",
            )
    except discord.HTTPException as e:
        logger.warning("Falha ao criar canal %s: %s", name, e)
        return None


# ── Views de Templates ────────────────────────────────────────────────────────

class TemplatesSelectView(discord.ui.View):
    """Select menu para escolha de template."""

    def __init__(
        self,
        ai_service: "AIService",
        backup_service: "BackupService",
        db: "DatabaseManager",
        user_plan: str,
    ) -> None:
        super().__init__(timeout=120)
        self.ai_service = ai_service
        self.backup_service = backup_service
        self.db = db
        self.user_plan = user_plan

        options = []
        for key, tmpl in TEMPLATES.items():
            is_premium = tmpl.get("premium", False)
            label = tmpl["name"]
            if is_premium and user_plan == "free":
                label += " (Premium)"
            options.append(discord.SelectOption(
                label=label[:25],
                value=key,
                description=tmpl["description"][:50],
            ))

        self.template_select.options = options

    @discord.ui.select(
        placeholder="Escolha um template...",
        min_values=1,
        max_values=1,
    )
    async def template_select(
        self, interaction: discord.Interaction, select: discord.ui.Select
    ) -> None:
        key = select.values[0]
        tmpl = TEMPLATES.get(key)

        if not tmpl:
            await interaction.response.send_message(
                embed=error_embed("Template não encontrado", "Tente novamente."),
                ephemeral=True,
            )
            return

        from config.settings import PLAN_HIERARCHY
        is_premium = tmpl.get("premium", False)
        user_idx = PLAN_HIERARCHY.index(self.user_plan)

        if is_premium and user_idx < PLAN_HIERARCHY.index("bronze"):
            from utils.embeds import premium_required_embed
            from views.premium_views import PremiumRequiredView
            await interaction.response.send_message(
                embed=premium_required_embed("bronze", self.user_plan, f"O template **{tmpl['name']}**"),
                view=PremiumRequiredView(),
                ephemeral=True,
            )
            return

        # Mostrar prévia do template
        embed = discord.Embed(
            title=f"{tmpl['name']}",
            description=tmpl["description"],
            color=0x00BFFF,
        )
        embed.add_field(
            name="📝 Descrição do Template",
            value=f"> {tmpl['prompt'][:200]}...",
            inline=False,
        )
        embed.set_footer(text="Shard App • Sua solução completa para servidores Discord")
        embed.set_thumbnail(url="https://i.ibb.co/8nMttsRX/6fa3f30915ff9c68cefe6f35cf07c080.jpg")

        view = TemplateConfirmView(
            template_key=key,
            template_data=tmpl,
            ai_service=self.ai_service,
            backup_service=self.backup_service,
            db=self.db,
            user_plan=self.user_plan,
        )
        await interaction.response.edit_message(embed=embed, view=view)


class TemplateConfirmView(discord.ui.View):
    """Confirmação para aplicar um template."""

    def __init__(
        self,
        template_key: str,
        template_data: dict,
        ai_service: "AIService",
        backup_service: "BackupService",
        db: "DatabaseManager",
        user_plan: str,
    ) -> None:
        super().__init__(timeout=120)
        self.template_key = template_key
        self.template_data = template_data
        self.ai_service = ai_service
        self.backup_service = backup_service
        self.db = db
        self.user_plan = user_plan

    @discord.ui.button(label="✅ Aplicar Template", style=discord.ButtonStyle.success)
    async def apply(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        """Abre o modal com o prompt do template pré-preenchido."""
        modal = ServerCreateModal(
            ai_service=self.ai_service,
            backup_service=self.backup_service,
            db=self.db,
            user_plan=self.user_plan,
        )
        modal.description_input.default = self.template_data["prompt"]
        await interaction.response.send_modal(modal)

    @discord.ui.button(label="❌ Cancelar", style=discord.ButtonStyle.danger)
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await interaction.response.edit_message(
            embed=error_embed("Cancelado", "Seleção de template cancelada."),
            view=None,
        )
