"""
Shard App — Views de Backup
Select menus e confirmações para backup/restauração.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import discord

from utils.embeds import error_embed, success_embed, loading_embed

if TYPE_CHECKING:
    from services.backup_service import BackupService
    from database.manager import DatabaseManager

logger = logging.getLogger("shard.views.backup")


class RestoreSelectView(discord.ui.View):
    """Select menu para escolher qual backup restaurar."""

    def __init__(
        self,
        backups: list[dict],
        backup_service: "BackupService",
        db: "DatabaseManager",
    ) -> None:
        super().__init__(timeout=120)
        self.backup_service = backup_service
        self.db = db

        options = []
        for bk in backups[:25]:
            options.append(
                discord.SelectOption(
                    label=bk["name"][:25],
                    value=str(bk["id"]),
                    description=f"Criado em {bk['created_at'][:10]} | Servidor {bk['guild_id']}",
                )
            )

        self.backup_select.options = options
        self.backup_select.placeholder = "Escolha um backup para restaurar..."

    @discord.ui.select(min_values=1, max_values=1)
    async def backup_select(
        self, interaction: discord.Interaction, select: discord.ui.Select
    ) -> None:
        backup_id = int(select.values[0])
        backup = await self.db.get_backup(backup_id, interaction.user.id)

        if not backup:
            await interaction.response.send_message(
                embed=error_embed("Backup não encontrado", "Este backup não existe ou não pertence a você."),
                ephemeral=True,
            )
            return

        embed = discord.Embed(
            title="⚠️  Confirmar Restauração",
            description=(
                f"Você está prestes a restaurar o backup **{backup['name']}**.\n\n"
                "Esta ação irá **remover** toda a estrutura atual do servidor "
                "(canais, categorias e cargos permitidos pelo bot) e **recriar** "
                "a estrutura salva no backup.\n\n"
                "**Esta ação não pode ser desfeita!**"
            ),
            color=0xF39C12,
        )
        embed.add_field(
            name="📦 Backup",
            value=(
                f"> **Nome:** {backup['name']}\n"
                f"> **Criado em:** {backup['created_at'][:16]}\n"
                f"> **Categorias:** {len(backup['data'].get('categories', []))}\n"
                f"> **Cargos:** {len(backup['data'].get('roles', []))}"
            ),
            inline=False,
        )
        embed.set_footer(text="Shard App • Sua solução completa para servidores Discord")

        confirm_view = RestoreConfirmView(
            backup=backup,
            backup_service=self.backup_service,
        )
        await interaction.response.edit_message(embed=embed, view=confirm_view)


class RestoreConfirmView(discord.ui.View):
    """Botões de confirmação da restauração."""

    def __init__(self, backup: dict, backup_service: "BackupService") -> None:
        super().__init__(timeout=120)
        self.backup = backup
        self.backup_service = backup_service

    @discord.ui.button(label="✅ Restaurar", style=discord.ButtonStyle.success)
    async def confirm(
        self, interaction: discord.Interaction, button: discord.ui.Button
    ) -> None:
        await interaction.response.defer()
        guild = interaction.guild

        if not guild:
            await interaction.edit_original_response(
                embed=error_embed("Erro", "Este comando só pode ser usado em servidores."),
                view=None,
            )
            return

        status_messages = []

        async def progress(step: str) -> None:
            status_messages.append(step)
            try:
                await interaction.edit_original_response(
                    embed=loading_embed(step),
                    view=None,
                )
            except Exception:
                pass

        result = await self.backup_service.restore_backup(
            guild=guild,
            backup_data=self.backup["data"],
            progress_callback=progress,
        )

        embed = success_embed(
            "Servidor Restaurado!",
            f"O backup **{self.backup['name']}** foi aplicado com sucesso.",
        )
        embed.add_field(
            name="📊 Resultado",
            value=(
                f"> **Categorias criadas:** `{result['categories_created']}`\n"
                f"> **Cargos criados:** `{result['roles_created']}`\n"
                f"> **Tempo:** `{result['elapsed']:.1f}s`"
            ),
            inline=False,
        )
        if result["errors"]:
            embed.add_field(
                name="⚠️ Avisos",
                value="\n".join(f"> {e}" for e in result["errors"][:5]),
                inline=False,
            )
        embed.set_footer(text="Shard App • Sua solução completa para servidores Discord")

        await interaction.edit_original_response(embed=embed, view=None)

    @discord.ui.button(label="❌ Cancelar", style=discord.ButtonStyle.danger)
    async def cancel(
        self, interaction: discord.Interaction, button: discord.ui.Button
    ) -> None:
        await interaction.response.edit_message(
            embed=error_embed("Cancelado", "Restauração cancelada."),
            view=None,
        )


class DeleteSelectView(discord.ui.View):
    """Menu de seleção para excluir elementos do servidor."""

    def __init__(self) -> None:
        super().__init__(timeout=120)

    @discord.ui.select(
        placeholder="O que deseja excluir?",
        options=[
            discord.SelectOption(label="📂 Todas as Categorias", value="categories", description="Remove todas as categorias do servidor"),
            discord.SelectOption(label="💬 Todos os Canais", value="channels", description="Remove todos os canais de texto e voz"),
            discord.SelectOption(label="👑 Todos os Cargos", value="roles", description="Remove cargos que o bot pode excluir"),
            discord.SelectOption(label="🗑️ Tudo", value="all", description="Remove tudo que for possível"),
        ],
        min_values=1,
        max_values=1,
    )
    async def delete_select(
        self, interaction: discord.Interaction, select: discord.ui.Select
    ) -> None:
        choice = select.values[0]
        labels = {
            "categories": "todas as categorias",
            "channels": "todos os canais",
            "roles": "todos os cargos removíveis",
            "all": "toda a estrutura do servidor",
        }

        embed = discord.Embed(
            title="⚠️  Confirmar Exclusão",
            description=(
                f"Você está prestes a excluir **{labels[choice]}** deste servidor.\n\n"
                "**Esta ação não pode ser desfeita!**\n"
                "Recomendamos fazer um `/backup` antes de prosseguir."
            ),
            color=0xE74C3C,
        )
        embed.set_footer(text="Shard App • Sua solução completa para servidores Discord")

        await interaction.response.edit_message(
            embed=embed,
            view=DeleteConfirmView(choice=choice),
        )


class DeleteConfirmView(discord.ui.View):
    """Confirmação final de exclusão."""

    def __init__(self, choice: str) -> None:
        super().__init__(timeout=60)
        self.choice = choice

    @discord.ui.button(label="✅ Confirmar Exclusão", style=discord.ButtonStyle.danger)
    async def confirm(
        self, interaction: discord.Interaction, button: discord.ui.Button
    ) -> None:
        await interaction.response.defer()

        guild = interaction.guild
        if not guild:
            return

        bot_member = guild.me
        errors: list[str] = []
        count = 0

        from utils.helpers import safe_delete_channels, safe_delete_roles

        if self.choice in ("channels", "all"):
            removed, errs = await safe_delete_channels(guild, bot_member)
            count += removed
            errors.extend(errs)

        if self.choice in ("roles", "all"):
            removed, errs = await safe_delete_roles(guild, bot_member)
            count += removed
            errors.extend(errs)

        if self.choice == "categories":
            for cat in list(guild.categories):
                try:
                    await cat.delete(reason="Shard App — Exclusão solicitada")
                    count += 1
                except discord.HTTPException as e:
                    errors.append(f"Categoria {cat.name}: {e}")

        embed = success_embed(
            "Exclusão Concluída",
            f"**{count}** elementos foram removidos com sucesso.",
        )
        if errors:
            embed.add_field(
                name="⚠️ Itens não removidos",
                value="\n".join(f"> {e}" for e in errors[:5]),
                inline=False,
            )
        await interaction.edit_original_response(embed=embed, view=None)

    @discord.ui.button(label="❌ Cancelar", style=discord.ButtonStyle.secondary)
    async def cancel(
        self, interaction: discord.Interaction, button: discord.ui.Button
    ) -> None:
        await interaction.response.edit_message(
            embed=error_embed("Cancelado", "Exclusão cancelada."),
            view=None,
        )
