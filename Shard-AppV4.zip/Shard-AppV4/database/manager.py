"""
Shard App — Database Manager
Gerencia todas as operações SQLite de forma assíncrona.
"""

from __future__ import annotations

import asyncio
import datetime
import json
import logging
from typing import Any, Optional

import aiosqlite

logger = logging.getLogger("shard.database")

DB_PATH = "database/shard.db"


class DatabaseManager:
    """Gerenciador central do banco de dados SQLite."""

    def __init__(self, db_path: str = DB_PATH) -> None:
        self.db_path = db_path
        self._db: Optional[aiosqlite.Connection] = None

    # ── Conexão ──────────────────────────────────────────────────────────────

    async def connect(self) -> None:
        """Abre a conexão e cria as tabelas."""
        self._db = await aiosqlite.connect(self.db_path)
        self._db.row_factory = aiosqlite.Row
        await self._db.execute("PRAGMA journal_mode=WAL")
        await self._db.execute("PRAGMA foreign_keys=ON")
        await self._create_tables()
        logger.info("Banco de dados conectado: %s", self.db_path)

    async def close(self) -> None:
        """Fecha a conexão com o banco."""
        if self._db:
            await self._db.close()
            logger.info("Banco de dados desconectado.")

    @property
    def db(self) -> aiosqlite.Connection:
        if self._db is None:
            raise RuntimeError("Banco de dados não conectado. Chame connect() primeiro.")
        return self._db

    # ── Criação de Tabelas ────────────────────────────────────────────────────

    async def _create_tables(self) -> None:
        """Cria todas as tabelas necessárias."""
        async with self.db.executescript("""
            -- Usuários
            CREATE TABLE IF NOT EXISTS users (
                user_id     INTEGER PRIMARY KEY,
                username    TEXT NOT NULL,
                created_at  TEXT DEFAULT (datetime('now')),
                updated_at  TEXT DEFAULT (datetime('now'))
            );

            -- Planos Premium
            CREATE TABLE IF NOT EXISTS premium (
                user_id         INTEGER PRIMARY KEY,
                plan            TEXT NOT NULL DEFAULT 'free',
                activated_at    TEXT,
                expires_at      TEXT,
                granted_by      INTEGER,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            );

            -- Histórico Premium
            CREATE TABLE IF NOT EXISTS premium_history (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id     INTEGER NOT NULL,
                plan        TEXT NOT NULL,
                action      TEXT NOT NULL,
                granted_by  INTEGER,
                timestamp   TEXT DEFAULT (datetime('now'))
            );

            -- Limite diário de criações
            CREATE TABLE IF NOT EXISTS daily_usage (
                user_id     INTEGER NOT NULL,
                date        TEXT NOT NULL,
                count       INTEGER DEFAULT 0,
                PRIMARY KEY (user_id, date)
            );

            -- Histórico de criações de servidor
            CREATE TABLE IF NOT EXISTS server_history (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id     INTEGER NOT NULL,
                guild_id    INTEGER NOT NULL,
                prompt      TEXT,
                plan_used   TEXT,
                created_at  TEXT DEFAULT (datetime('now'))
            );

            -- Backups de servidor
            CREATE TABLE IF NOT EXISTS backups (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id     INTEGER NOT NULL,
                guild_id    INTEGER NOT NULL,
                name        TEXT NOT NULL,
                data        TEXT NOT NULL,
                created_at  TEXT DEFAULT (datetime('now'))
            );

            -- Configurações de Log por servidor
            CREATE TABLE IF NOT EXISTS log_settings (
                guild_id        INTEGER PRIMARY KEY,
                log_channel_id  INTEGER,
                log_ban         INTEGER DEFAULT 1,
                log_kick        INTEGER DEFAULT 1,
                log_clear       INTEGER DEFAULT 1,
                log_channel_create INTEGER DEFAULT 1,
                log_channel_delete INTEGER DEFAULT 1,
                log_member_join INTEGER DEFAULT 1,
                log_member_leave INTEGER DEFAULT 1,
                log_role_change INTEGER DEFAULT 1,
                log_nick_change INTEGER DEFAULT 1,
                log_commands    INTEGER DEFAULT 1
            );

            -- Auto Role por servidor
            CREATE TABLE IF NOT EXISTS autorole (
                guild_id    INTEGER PRIMARY KEY,
                role_id     INTEGER,
                message     TEXT,
                channel_id  INTEGER,
                enabled     INTEGER DEFAULT 1
            );

            -- Configurações de aparência por usuário
            CREATE TABLE IF NOT EXISTS appearance (
                user_id     INTEGER PRIMARY KEY,
                theme_color TEXT DEFAULT '#00BFFF',
                show_badge  INTEGER DEFAULT 1,
                compact     INTEGER DEFAULT 0
            );

            -- Templates utilizados
            CREATE TABLE IF NOT EXISTS template_usage (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id     INTEGER NOT NULL,
                guild_id    INTEGER NOT NULL,
                template    TEXT NOT NULL,
                used_at     TEXT DEFAULT (datetime('now'))
            );

            -- Configurações de proteção por servidor
            CREATE TABLE IF NOT EXISTS protection (
                guild_id            INTEGER PRIMARY KEY,
                enabled             INTEGER DEFAULT 0,
                anti_raid           INTEGER DEFAULT 0,
                anti_channel_create INTEGER DEFAULT 0,
                anti_channel_delete INTEGER DEFAULT 0,
                anti_role_create    INTEGER DEFAULT 0,
                alert_channel_id    INTEGER
            );

            -- Auditoria geral
            CREATE TABLE IF NOT EXISTS audit_log (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id    INTEGER,
                user_id     INTEGER,
                action      TEXT NOT NULL,
                details     TEXT,
                timestamp   TEXT DEFAULT (datetime('now'))
            );
        """):
            pass
        await self.db.commit()
        logger.info("Tabelas verificadas/criadas com sucesso.")

    # ── Usuários ──────────────────────────────────────────────────────────────

    async def ensure_user(self, user_id: int, username: str) -> None:
        """Garante que o usuário existe no banco."""
        await self.db.execute(
            """
            INSERT INTO users (user_id, username, updated_at)
            VALUES (?, ?, datetime('now'))
            ON CONFLICT(user_id) DO UPDATE SET
                username   = excluded.username,
                updated_at = excluded.updated_at
            """,
            (user_id, username),
        )
        await self.db.commit()

    # ── Premium ───────────────────────────────────────────────────────────────

    async def get_premium(self, user_id: int) -> dict[str, Any]:
        """Retorna os dados do plano do usuário."""
        async with self.db.execute(
            "SELECT * FROM premium WHERE user_id = ?", (user_id,)
        ) as cur:
            row = await cur.fetchone()

        if not row:
            return {"plan": "free", "expires_at": None, "activated_at": None, "granted_by": None}

        data = dict(row)
        # Verificar expiração
        if data.get("expires_at"):
            exp = datetime.datetime.fromisoformat(data["expires_at"])
            if exp < datetime.datetime.utcnow():
                # Plano expirado → regredir para free
                await self.db.execute(
                    "DELETE FROM premium WHERE user_id = ?", (user_id,)
                )
                await self.db.commit()
                return {"plan": "free", "expires_at": None, "activated_at": None, "granted_by": None}
        return data

    async def set_premium(
        self,
        user_id: int,
        plan: str,
        days: int,
        granted_by: int,
    ) -> datetime.datetime:
        """Define ou atualiza o plano Premium do usuário. Retorna a data de expiração."""
        now = datetime.datetime.utcnow()
        expires_at = now + datetime.timedelta(days=days)

        await self.db.execute(
            """
            INSERT INTO premium (user_id, plan, activated_at, expires_at, granted_by)
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET
                plan         = excluded.plan,
                activated_at = excluded.activated_at,
                expires_at   = excluded.expires_at,
                granted_by   = excluded.granted_by
            """,
            (user_id, plan, now.isoformat(), expires_at.isoformat(), granted_by),
        )
        await self.db.execute(
            """
            INSERT INTO premium_history (user_id, plan, action, granted_by)
            VALUES (?, ?, 'granted', ?)
            """,
            (user_id, plan, granted_by),
        )
        await self.db.commit()
        return expires_at

    async def remove_premium(self, user_id: int, removed_by: int) -> None:
        """Remove o plano Premium do usuário."""
        async with self.db.execute(
            "SELECT plan FROM premium WHERE user_id = ?", (user_id,)
        ) as cur:
            row = await cur.fetchone()

        if row:
            await self.db.execute(
                """
                INSERT INTO premium_history (user_id, plan, action, granted_by)
                VALUES (?, ?, 'removed', ?)
                """,
                (user_id, row["plan"], removed_by),
            )
        await self.db.execute("DELETE FROM premium WHERE user_id = ?", (user_id,))
        await self.db.commit()

    async def get_premium_history(self, user_id: int) -> list[dict]:
        """Retorna o histórico Premium do usuário."""
        async with self.db.execute(
            "SELECT * FROM premium_history WHERE user_id = ? ORDER BY timestamp DESC LIMIT 10",
            (user_id,),
        ) as cur:
            rows = await cur.fetchall()
        return [dict(r) for r in rows]

    # ── Limite Diário ─────────────────────────────────────────────────────────

    async def get_daily_usage(self, user_id: int) -> int:
        """Retorna quantas criações o usuário fez hoje."""
        today = datetime.date.today().isoformat()
        async with self.db.execute(
            "SELECT count FROM daily_usage WHERE user_id = ? AND date = ?",
            (user_id, today),
        ) as cur:
            row = await cur.fetchone()
        return row["count"] if row else 0

    async def increment_daily_usage(self, user_id: int) -> int:
        """Incrementa o contador de criações diárias. Retorna o novo total."""
        today = datetime.date.today().isoformat()
        await self.db.execute(
            """
            INSERT INTO daily_usage (user_id, date, count) VALUES (?, ?, 1)
            ON CONFLICT(user_id, date) DO UPDATE SET count = count + 1
            """,
            (user_id, today),
        )
        await self.db.commit()
        async with self.db.execute(
            "SELECT count FROM daily_usage WHERE user_id = ? AND date = ?",
            (user_id, today),
        ) as cur:
            row = await cur.fetchone()
        return row["count"] if row else 1

    # ── Histórico de Servidores ───────────────────────────────────────────────

    async def add_server_creation(
        self, user_id: int, guild_id: int, prompt: str, plan: str
    ) -> None:
        await self.db.execute(
            "INSERT INTO server_history (user_id, guild_id, prompt, plan_used) VALUES (?, ?, ?, ?)",
            (user_id, guild_id, prompt, plan),
        )
        await self.db.commit()

    async def get_server_creation_count(self, user_id: int) -> int:
        async with self.db.execute(
            "SELECT COUNT(*) as total FROM server_history WHERE user_id = ?", (user_id,)
        ) as cur:
            row = await cur.fetchone()
        return row["total"] if row else 0

    # ── Backups ───────────────────────────────────────────────────────────────

    async def save_backup(
        self,
        user_id: int,
        guild_id: int,
        name: str,
        data: dict,
    ) -> int:
        """Salva um backup e retorna o ID gerado."""
        async with self.db.execute(
            "INSERT INTO backups (user_id, guild_id, name, data) VALUES (?, ?, ?, ?)",
            (user_id, guild_id, name, json.dumps(data, ensure_ascii=False)),
        ) as cur:
            backup_id = cur.lastrowid
        await self.db.commit()
        return backup_id  # type: ignore

    async def get_user_backups(self, user_id: int) -> list[dict]:
        """Lista todos os backups do usuário."""
        async with self.db.execute(
            "SELECT id, guild_id, name, created_at FROM backups WHERE user_id = ? ORDER BY created_at DESC",
            (user_id,),
        ) as cur:
            rows = await cur.fetchall()
        return [dict(r) for r in rows]

    async def get_backup(self, backup_id: int, user_id: int) -> Optional[dict]:
        """Retorna um backup específico (apenas se pertencer ao usuário)."""
        async with self.db.execute(
            "SELECT * FROM backups WHERE id = ? AND user_id = ?",
            (backup_id, user_id),
        ) as cur:
            row = await cur.fetchone()
        if not row:
            return None
        d = dict(row)
        d["data"] = json.loads(d["data"])
        return d

    async def get_backup_count(self, user_id: int) -> int:
        async with self.db.execute(
            "SELECT COUNT(*) as total FROM backups WHERE user_id = ?", (user_id,)
        ) as cur:
            row = await cur.fetchone()
        return row["total"] if row else 0

    # ── Log Settings ──────────────────────────────────────────────────────────

    async def get_log_settings(self, guild_id: int) -> Optional[dict]:
        async with self.db.execute(
            "SELECT * FROM log_settings WHERE guild_id = ?", (guild_id,)
        ) as cur:
            row = await cur.fetchone()
        return dict(row) if row else None

    async def set_log_channel(self, guild_id: int, channel_id: int) -> None:
        await self.db.execute(
            """
            INSERT INTO log_settings (guild_id, log_channel_id)
            VALUES (?, ?)
            ON CONFLICT(guild_id) DO UPDATE SET log_channel_id = excluded.log_channel_id
            """,
            (guild_id, channel_id),
        )
        await self.db.commit()

    # ── Auto Role ─────────────────────────────────────────────────────────────

    async def get_autorole(self, guild_id: int) -> Optional[dict]:
        async with self.db.execute(
            "SELECT * FROM autorole WHERE guild_id = ?", (guild_id,)
        ) as cur:
            row = await cur.fetchone()
        return dict(row) if row else None

    async def set_autorole(
        self,
        guild_id: int,
        role_id: int,
        message: str,
        channel_id: int,
    ) -> None:
        await self.db.execute(
            """
            INSERT INTO autorole (guild_id, role_id, message, channel_id, enabled)
            VALUES (?, ?, ?, ?, 1)
            ON CONFLICT(guild_id) DO UPDATE SET
                role_id    = excluded.role_id,
                message    = excluded.message,
                channel_id = excluded.channel_id,
                enabled    = 1
            """,
            (guild_id, role_id, message, channel_id),
        )
        await self.db.commit()

    # ── Proteção ──────────────────────────────────────────────────────────────

    async def get_protection(self, guild_id: int) -> Optional[dict]:
        async with self.db.execute(
            "SELECT * FROM protection WHERE guild_id = ?", (guild_id,)
        ) as cur:
            row = await cur.fetchone()
        return dict(row) if row else None

    async def set_protection(self, guild_id: int, settings: dict) -> None:
        await self.db.execute(
            """
            INSERT INTO protection (
                guild_id, enabled, anti_raid,
                anti_channel_create, anti_channel_delete,
                anti_role_create, alert_channel_id
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(guild_id) DO UPDATE SET
                enabled             = excluded.enabled,
                anti_raid           = excluded.anti_raid,
                anti_channel_create = excluded.anti_channel_create,
                anti_channel_delete = excluded.anti_channel_delete,
                anti_role_create    = excluded.anti_role_create,
                alert_channel_id    = excluded.alert_channel_id
            """,
            (
                guild_id,
                settings.get("enabled", 1),
                settings.get("anti_raid", 1),
                settings.get("anti_channel_create", 1),
                settings.get("anti_channel_delete", 1),
                settings.get("anti_role_create", 1),
                settings.get("alert_channel_id"),
            ),
        )
        await self.db.commit()

    # ── Auditoria ─────────────────────────────────────────────────────────────

    async def add_audit(
        self,
        guild_id: Optional[int],
        user_id: Optional[int],
        action: str,
        details: Optional[str] = None,
    ) -> None:
        await self.db.execute(
            "INSERT INTO audit_log (guild_id, user_id, action, details) VALUES (?, ?, ?, ?)",
            (guild_id, user_id, action, details),
        )
        await self.db.commit()
