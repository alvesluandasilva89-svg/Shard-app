"""
Shard App — Comandos de Administração
/logs configurar, /autorole configurar, /embed, /aparencia, /excluir, /proteger
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import discord
from discord import app_commands
from discord.ext import commands

from config.settings import EMOJI, PLAN_HIERARCHY
from utils.checks import get_user_plan, plan_meets_requirement
from utils.embeds import error_embed, success_embed, premium_required_embed
from views.premium_views import PremiumRequiredView
from views.backup_views import DeleteSelectView

if TYPE_CHECKING:
    from main import ShardBot

logger = logging.getLogger("shard.commands.admin")


class AdminCommands(commands.Cog):
    """Comandos de administração do servidor."""

    def __init__(self, bot: "ShardBot") -> None:
        self.bot = bot

    logs_group = app_commands.Group(
        name="logs", description="Configurações do sistema de logs"
    )
    autorole_group = app_commands.Group(
        name="autorole", description="Configurações de cargo automático"
    )

    # ── /logs configurar ──────────────────────────────────────────────────────

    @logs_group.command(
        name="configurar", description="Configura o canal de logs do servidor"
    )
    @app_commands.describe(canal="Canal onde os logs serão enviados")
    async def logs_configurar(
        self,
        interaction: discord.Interaction,
        canal: discord.TextChannel,
    ) -> None:
        if not interaction.guild:
            await interaction.response.send_message(
                embed=error_embed("Erro", "Use em um servidor."), ephemeral=True
            )
            return

        # Verificar plano Bronze+
        plan = await get_user_plan(self.bot.db, interaction.user.id)
        if not plan_meets_requirement(plan, "bronze"):
            await interaction.response.send_message(
                embed=premium_required_embed("bronze", plan, "O sistema de Logs"),
                view=PremiumRequiredView(),
                ephemeral=True,
            )
            return

        # Verificar permissão no servidor
        if not interaction.user.guild_permissions.manage_guild:  # type: ignore
            await interaction.response.send_message(
                embed=error_embed("Permissão Negada", "Você precisa de **Gerenciar Servidor** para configurar logs."),
                ephemeral=True,
            )
            return

        await self.bot.db.set_log_channel(interaction.guild.id, canal.id)

        embed = success_embed(
            "Logs Configurado!",
            f"Os logs serão enviados em {canal.mention}.",
        )
        embed.add_field(
            name=f"{EMOJI['setting']}  Eventos monitorados",
            value=(
                "> Entradas e saídas de membros\n"
                "> Banimentos e kicks\n"
                "> Criação e exclusão de canais\n"
                "> Mudanças de cargo e apelido\n"
                "> Limpeza de mensagens\n"
                "> Uso de comandos administrativos"
            ),
            inline=False,
        )
        embed.set_footer(text="Shard App • Sua solução completa para servidores Discord")
        embed.set_thumbnail(url="https://i.ibb.co/8nMttsRX/6fa3f30915ff9c68cefe6f35cf07c080.jpg")

        await interaction.response.send_message(embed=embed, ephemeral=True)

    # ── /autorole configurar ──────────────────────────────────────────────────

    @autorole_group.command(
        name="configurar", description="Configura o cargo automático para novos membros"
    )
    @app_commands.describe(
        cargo="Cargo a ser atribuído automaticamente",
        canal="Canal para mensagem de boas-vindas (opcional)",
        mensagem="Mensagem de boas-vindas. Use {user}, {server}, {count} (opcional)",
    )
    async def autorole_configurar(
        self,
        interaction: discord.Interaction,
        cargo: discord.Role,
        canal: discord.TextChannel | None = None,
        mensagem: str | None = None,
    ) -> None:
        if not interaction.guild:
            await interaction.response.send_message(
                embed=error_embed("Erro", "Use em um servidor."), ephemeral=True
            )
            return

        # Verificar plano Bronze+
        plan = await get_user_plan(self.bot.db, interaction.user.id)
        if not plan_meets_requirement(plan, "bronze"):
            await interaction.response.send_message(
                embed=premium_required_embed("bronze", plan, "O Auto Role"),
                view=PremiumRequiredView(),
                ephemeral=True,
            )
            return

        if not interaction.user.guild_permissions.manage_roles:  # type: ignore
            await interaction.response.send_message(
                embed=error_embed("Permissão Negada", "Você precisa de **Gerenciar Cargos**."),
                ephemeral=True,
            )
            return

        # Verificar hierarquia
        if cargo >= interaction.guild.me.top_role:
            await interaction.response.send_message(
                embed=error_embed(
                    "Hierarquia Inválida",
                    f"O cargo {cargo.mention} está acima do meu cargo mais alto.",
                ),
                ephemeral=True,
            )
            return

        await self.bot.db.set_autorole(
            guild_id=interaction.guild.id,
            role_id=cargo.id,
            message=mensagem or f"Bem-vindo ao servidor, {{user}}! 🎉",
            channel_id=canal.id if canal else 0,
        )

        embed = success_embed(
            "Auto Role Configurado!",
            f"O cargo {cargo.mention} será atribuído automaticamente a novos membros.",
        )
        if canal:
            embed.add_field(name="Canal", value=canal.mention, inline=True)
        if mensagem:
            embed.add_field(name="Mensagem", value=f"> {mensagem[:200]}", inline=False)
        embed.set_footer(text="Shard App • Sua solução completa para servidores Discord")
        embed.set_thumbnail(url="https://i.ibb.co/8nMttsRX/6fa3f30915ff9c68cefe6f35cf07c080.jpg")

        await interaction.response.send_message(embed=embed, ephemeral=True)

    # ── /embed ────────────────────────────────────────────────────────────────

    @app_commands.command(
        name="embed", description="Cria e envia uma embed personalizada"
    )
    @app_commands.describe(canal="Canal onde a embed será enviada")
    async def embed_cmd(
        self, interaction: discord.Interaction, canal: discord.TextChannel
    ) -> None:
        # Verificar plano Bronze+
        plan = await get_user_plan(self.bot.db, interaction.user.id)
        if not plan_meets_requirement(plan, "bronze"):
            await interaction.response.send_message(
                embed=premium_required_embed("bronze", plan, "O comando /embed"),
                view=PremiumRequiredView(),
                ephemeral=True,
            )
            return

        await interaction.response.send_modal(EmbedModal(canal=canal))

    # ── /aparencia ────────────────────────────────────────────────────────────

    @app_commands.command(
        name="aparencia", description="Personaliza a aparência do bot no seu perfil"
    )
    async def aparencia(self, interaction: discord.Interaction) -> None:
        plan = await get_user_plan(self.bot.db, interaction.user.id)
        if not plan_meets_requirement(plan, "diamond"):
            await interaction.response.send_message(
                embed=premium_required_embed("diamond", plan, "O comando /aparencia"),
                view=PremiumRequiredView(),
                ephemeral=True,
            )
            return

        await interaction.response.send_modal(AparenciaModal(db=self.bot.db))

    # ── /excluir ──────────────────────────────────────────────────────────────

    @app_commands.command(
        name="excluir", description="Exclui canais, categorias ou cargos do servidor"
    )
    async def excluir(self, interaction: discord.Interaction) -> None:
        if not interaction.guild:
            await interaction.response.send_message(
                embed=error_embed("Erro", "Use em um servidor."), ephemeral=True
            )
            return

        if not interaction.user.guild_permissions.manage_channels:  # type: ignore
            await interaction.response.send_message(
                embed=error_embed("Permissão Negada", "Você precisa de **Gerenciar Canais**."),
                ephemeral=True,
            )
            return

        embed = discord.Embed(
            title=f"{EMOJI['clear']}  Excluir Elementos",
            description=(
                "Selecione abaixo o que deseja excluir do servidor.\n"
                "Esta ação é permanente. Recomendamos fazer um `/backup` antes."
            ),
            color=0xE74C3C,
        )
        embed.set_footer(text="Shard App • Sua solução completa para servidores Discord")
        embed.set_thumbnail(url="https://i.ibb.co/8nMttsRX/6fa3f30915ff9c68cefe6f35cf07c080.jpg")

        await interaction.response.send_message(
            embed=embed, view=DeleteSelectView(), ephemeral=True
        )

    # ── /proteger ─────────────────────────────────────────────────────────────

    @app_commands.command(
        name="proteger",
        description="Ativa a proteção Anti-Raid e auditoria avançada do servidor"
    )
    @app_commands.describe(
        canal_alertas="Canal onde os alertas de segurança serão enviados"
    )
    async def proteger(
        self,
        interaction: discord.Interaction,
        canal_alertas: discord.TextChannel,
    ) -> None:
        if not interaction.guild:
            await interaction.response.send_message(
                embed=error_embed("Erro", "Use em um servidor."), ephemeral=True
            )
            return

        plan = await get_user_plan(self.bot.db, interaction.user.id)
        if not plan_meets_requirement(plan, "emerald"):
            await interaction.response.send_message(
                embed=premium_required_embed("emerald", plan, "O sistema de Proteção"),
                view=PremiumRequiredView(),
                ephemeral=True,
            )
            return

        if not interaction.user.guild_permissions.administrator:  # type: ignore
            await interaction.response.send_message(
                embed=error_embed("Permissão Negada", "Você precisa de **Administrador** para ativar proteção."),
                ephemeral=True,
            )
            return

        settings = {
            "enabled": 1,
            "anti_raid": 1,
            "anti_channel_create": 1,
            "anti_channel_delete": 1,
            "anti_role_create": 1,
            "alert_channel_id": canal_alertas.id,
        }
        await self.bot.db.set_protection(interaction.guild.id, settings)

        embed = success_embed(
            "Proteção Ativada!",
            f"O servidor está agora protegido. Alertas serão enviados em {canal_alertas.mention}.",
        )
        embed.add_field(
            name=f"{EMOJI['super_shield']}  Proteções ativas",
            value=(
                f"> {EMOJI['shield']} Anti-Raid (entradas em massa)\n"
                f"> {EMOJI['shield']} Anti-criação de canais não autorizada\n"
                f"> {EMOJI['shield']} Anti-exclusão de canais\n"
                f"> {EMOJI['shield']} Monitoramento de cargos\n"
                f"> {EMOJI['shield']} Sistema de auditoria"
            ),
            inline=False,
        )
        embed.set_footer(text="Shard App • Sua solução completa para servidores Discord")
        embed.set_thumbnail(url="https://i.ibb.co/8nMttsRX/6fa3f30915ff9c68cefe6f35cf07c080.jpg")

        await interaction.response.send_message(embed=embed, ephemeral=True)


# ── Modais Inline ─────────────────────────────────────────────────────────────

class EmbedModal(discord.ui.Modal, title="Criar Embed"):
    titulo = discord.ui.TextInput(
        label="Título", placeholder="Título da embed", max_length=256, required=True
    )
    descricao = discord.ui.TextInput(
        label="Descrição",
        placeholder="Conteúdo principal da embed",
        style=discord.TextStyle.paragraph,
        max_length=2000,
        required=True,
    )
    cor = discord.ui.TextInput(
        label="Cor (hex)",
        placeholder="#00BFFF",
        default="#00BFFF",
        max_length=7,
        required=False,
    )
    imagem = discord.ui.TextInput(
        label="URL da imagem (opcional)",
        placeholder="https://...",
        required=False,
    )
    rodape = discord.ui.TextInput(
        label="Rodapé (opcional)",
        placeholder="Texto do rodapé",
        max_length=2048,
        required=False,
    )

    def __init__(self, canal: discord.TextChannel) -> None:
        super().__init__(timeout=300)
        self.canal = canal

    async def on_submit(self, interaction: discord.Interaction) -> None:
        from utils.helpers import color_from_hex
        color = color_from_hex(self.cor.value or "#00BFFF")

        embed = discord.Embed(
            title=self.titulo.value,
            description=self.descricao.value,
            color=color,
        )
        if self.rodape.value:
            embed.set_footer(text=self.rodape.value)
        if self.imagem.value:
            try:
                embed.set_image(url=self.imagem.value)
            except Exception:
                pass

        try:
            await self.canal.send(embed=embed)
            await interaction.response.send_message(
                embed=success_embed("Embed Enviada!", f"Sua embed foi enviada em {self.canal.mention}."),
                ephemeral=True,
            )
        except discord.HTTPException as e:
            await interaction.response.send_message(
                embed=error_embed("Erro", f"Não foi possível enviar a embed: {e}"),
                ephemeral=True,
            )


class AparenciaModal(discord.ui.Modal, title="Personalizar Aparência"):
    cor_tema = discord.ui.TextInput(
        label="Cor do tema (hex)",
        placeholder="#00BFFF",
        default="#00BFFF",
        max_length=7,
        required=False,
    )

    def __init__(self, db) -> None:
        super().__init__(timeout=300)
        self.db = db

    async def on_submit(self, interaction: discord.Interaction) -> None:
        await interaction.response.send_message(
            embed=success_embed(
                "Aparência Salva!",
                f"Sua cor de tema foi definida para `{self.cor_tema.value or '#00BFFF'}`.",
            ),
            ephemeral=True,
        )


async def setup(bot: "ShardBot") -> None:
    await bot.add_cog(AdminCommands(bot))
