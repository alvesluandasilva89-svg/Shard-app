"""
Shard App — Comandos de Backup e Restauração
/backup, /restaurar
"""

from __future__ import annotations

import datetime
import logging
from typing import TYPE_CHECKING

import discord
from discord import app_commands
from discord.ext import commands

from utils.embeds import backup_created_embed, error_embed
from views.backup_views import RestoreSelectView

if TYPE_CHECKING:
    from main import ShardBot

logger = logging.getLogger("shard.commands.backup")


class BackupCommands(commands.Cog):
    """Comandos de backup e restauração de servidores."""

    def __init__(self, bot: "ShardBot") -> None:
        self.bot = bot

    # ── /backup ───────────────────────────────────────────────────────────────

    @app_commands.command(
        name="backup", description="Cria um backup completo da estrutura do servidor"
    )
    @app_commands.describe(nome="Nome para identificar o backup (opcional)")
    async def backup(
        self,
        interaction: discord.Interaction,
        nome: str | None = None,
    ) -> None:
        if not interaction.guild:
            await interaction.response.send_message(
                embed=error_embed("Erro", "Use este comando em um servidor."),
                ephemeral=True,
            )
            return

        # Verificar permissão básica
        if not interaction.user.guild_permissions.manage_guild:  # type: ignore
            await interaction.response.send_message(
                embed=error_embed(
                    "Permissão Negada",
                    "Você precisa de **Gerenciar Servidor** para criar backups.",
                ),
                ephemeral=True,
            )
            return

        await interaction.response.defer(ephemeral=True, thinking=True)

        await self.bot.db.ensure_user(interaction.user.id, str(interaction.user))

        try:
            result = await self.bot.backup_service.create_backup(
                guild=interaction.guild,
                user_id=interaction.user.id,
                name=nome,
            )
        except Exception as e:
            logger.error("Erro ao criar backup: %s", e)
            await interaction.followup.send(
                embed=error_embed("Erro ao criar backup", "Ocorreu um erro interno. Tente novamente."),
                ephemeral=True,
            )
            return

        embed = backup_created_embed(
            name=result["name"],
            channels=result["channels"],
            categories=result["categories"],
            roles=result["roles"],
            elapsed=result["elapsed"],
        )
        embed.add_field(
            name="🆔 ID do Backup",
            value=f"> `{result['id']}`",
            inline=True,
        )
        embed.add_field(
            name="💡 Dica",
            value="> Use `/restaurar` para recuperar este backup.",
            inline=False,
        )

        await interaction.followup.send(embed=embed, ephemeral=True)
        logger.info(
            "Backup criado: id=%d guild=%d user=%d",
            result["id"], interaction.guild.id, interaction.user.id,
        )

    # ── /restaurar ────────────────────────────────────────────────────────────

    @app_commands.command(
        name="restaurar", description="Restaura um backup salvo no servidor atual"
    )
    async def restaurar(self, interaction: discord.Interaction) -> None:
        if not interaction.guild:
            await interaction.response.send_message(
                embed=error_embed("Erro", "Use este comando em um servidor."),
                ephemeral=True,
            )
            return

        if not interaction.user.guild_permissions.administrator:  # type: ignore
            await interaction.response.send_message(
                embed=error_embed(
                    "Permissão Negada",
                    "Você precisa de **Administrador** para restaurar backups.",
                ),
                ephemeral=True,
            )
            return

        await self.bot.db.ensure_user(interaction.user.id, str(interaction.user))
        backups = await self.bot.db.get_user_backups(interaction.user.id)

        if not backups:
            await interaction.response.send_message(
                embed=error_embed(
                    "Nenhum Backup Encontrado",
                    "Você ainda não possui backups salvos.\nUse `/backup` para criar um.",
                ),
                ephemeral=True,
            )
            return

        embed = discord.Embed(
            title="♻️  Restaurar Backup",
            description=(
                f"Você possui **{len(backups)}** backup(s) disponível(is).\n"
                "Selecione abaixo qual deseja restaurar.\n\n"
                "⚠️ **Atenção:** Esta ação removerá a estrutura atual do servidor!"
            ),
            color=0xF39C12,
        )
        embed.set_footer(text="Shard App • Sua solução completa para servidores Discord")
        embed.set_thumbnail(url="https://i.ibb.co/8nMttsRX/6fa3f30915ff9c68cefe6f35cf07c080.jpg")

        view = RestoreSelectView(
            backups=backups,
            backup_service=self.bot.backup_service,
            db=self.bot.db,
        )
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)


async def setup(bot: "ShardBot") -> None:
    await bot.add_cog(BackupCommands(bot))
