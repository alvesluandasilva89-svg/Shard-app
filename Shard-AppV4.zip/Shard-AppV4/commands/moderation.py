"""
Shard App — Comandos de Moderação
/ban, /kick, /limpar
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import discord
from discord import app_commands
from discord.ext import commands

from config.settings import EMOJI
from utils.embeds import error_embed, success_embed

if TYPE_CHECKING:
    from main import ShardBot

logger = logging.getLogger("shard.commands.moderation")


class ModerationCommands(commands.Cog):
    """Comandos de moderação do servidor."""

    def __init__(self, bot: "ShardBot") -> None:
        self.bot = bot

    # ── /ban ──────────────────────────────────────────────────────────────────

    @app_commands.command(name="ban", description="Bane um membro permanentemente do servidor")
    @app_commands.describe(
        membro="Membro a ser banido",
        motivo="Motivo do banimento",
        deletar_mensagens="Dias de mensagens para deletar (0-7)",
    )
    async def ban(
        self,
        interaction: discord.Interaction,
        membro: discord.Member,
        motivo: str,
        deletar_mensagens: app_commands.Range[int, 0, 7] = 1,
    ) -> None:
        if not interaction.guild:
            await interaction.response.send_message(
                embed=error_embed("Erro", "Use em um servidor."), ephemeral=True
            )
            return

        # Verificar permissões
        if not interaction.user.guild_permissions.ban_members:  # type: ignore
            await interaction.response.send_message(
                embed=error_embed("Permissão Negada", "Você precisa de **Banir Membros**."),
                ephemeral=True,
            )
            return

        if not interaction.guild.me.guild_permissions.ban_members:
            await interaction.response.send_message(
                embed=error_embed("Permissão Insuficiente", "Não tenho permissão para banir membros."),
                ephemeral=True,
            )
            return

        # Hierarquia
        if membro.top_role >= interaction.guild.me.top_role:
            await interaction.response.send_message(
                embed=error_embed("Hierarquia", "Não posso banir este membro (cargo igual ou superior ao meu)."),
                ephemeral=True,
            )
            return

        if membro.top_role >= interaction.user.top_role:  # type: ignore
            await interaction.response.send_message(
                embed=error_embed("Hierarquia", "Você não pode banir alguém com cargo igual ou superior ao seu."),
                ephemeral=True,
            )
            return

        # Tentar enviar DM ao banido
        try:
            dm_embed = discord.Embed(
                title=f"🔨  Você foi banido",
                description=(
                    f"Você foi banido de **{interaction.guild.name}**.\n"
                    f"**Motivo:** {motivo}"
                ),
                color=0xE74C3C,
            )
            dm_embed.set_footer(text="Shard App • Sua solução completa para servidores Discord")
            await membro.send(embed=dm_embed)
        except (discord.Forbidden, discord.HTTPException):
            pass

        try:
            await membro.ban(
                reason=f"[Shard App] {interaction.user} — {motivo}",
                delete_message_days=deletar_mensagens,
            )
        except discord.HTTPException as e:
            await interaction.response.send_message(
                embed=error_embed("Erro", f"Não foi possível banir: {e}"),
                ephemeral=True,
            )
            return

        # Registrar log
        await self._send_log(
            interaction.guild,
            f"{EMOJI['ban']} **{membro}** foi banido por **{interaction.user}**.\n> **Motivo:** {motivo}",
            "ban",
        )
        await self.bot.db.add_audit(
            guild_id=interaction.guild.id,
            user_id=interaction.user.id,
            action="ban",
            details=f"Banido: {membro} | Motivo: {motivo}",
        )

        embed = success_embed(
            "Membro Banido",
            f"**{membro}** foi banido com sucesso.",
        )
        embed.add_field(name="Motivo", value=f"> {motivo}", inline=False)
        embed.add_field(name="Moderador", value=f"> {interaction.user.mention}", inline=True)
        embed.set_thumbnail(url=membro.display_avatar.url)
        embed.set_footer(text="Shard App • Sua solução completa para servidores Discord")

        await interaction.response.send_message(embed=embed)

    # ── /kick ─────────────────────────────────────────────────────────────────

    @app_commands.command(name="kick", description="Expulsa um membro do servidor")
    @app_commands.describe(membro="Membro a ser expulso", motivo="Motivo da expulsão")
    async def kick(
        self,
        interaction: discord.Interaction,
        membro: discord.Member,
        motivo: str,
    ) -> None:
        if not interaction.guild:
            await interaction.response.send_message(
                embed=error_embed("Erro", "Use em um servidor."), ephemeral=True
            )
            return

        if not interaction.user.guild_permissions.kick_members:  # type: ignore
            await interaction.response.send_message(
                embed=error_embed("Permissão Negada", "Você precisa de **Expulsar Membros**."),
                ephemeral=True,
            )
            return

        if not interaction.guild.me.guild_permissions.kick_members:
            await interaction.response.send_message(
                embed=error_embed("Permissão Insuficiente", "Não tenho permissão para expulsar membros."),
                ephemeral=True,
            )
            return

        if membro.top_role >= interaction.guild.me.top_role:
            await interaction.response.send_message(
                embed=error_embed("Hierarquia", "Não posso expulsar este membro."),
                ephemeral=True,
            )
            return

        # DM ao expulso
        try:
            dm_embed = discord.Embed(
                title="👢  Você foi expulso",
                description=f"Você foi expulso de **{interaction.guild.name}**.\n**Motivo:** {motivo}",
                color=0xE67E22,
            )
            dm_embed.set_footer(text="Shard App • Sua solução completa para servidores Discord")
            await membro.send(embed=dm_embed)
        except (discord.Forbidden, discord.HTTPException):
            pass

        try:
            await membro.kick(reason=f"[Shard App] {interaction.user} — {motivo}")
        except discord.HTTPException as e:
            await interaction.response.send_message(
                embed=error_embed("Erro", f"Não foi possível expulsar: {e}"),
                ephemeral=True,
            )
            return

        await self._send_log(
            interaction.guild,
            f"👢 **{membro}** foi expulso por **{interaction.user}**.\n> **Motivo:** {motivo}",
            "kick",
        )
        await self.bot.db.add_audit(
            guild_id=interaction.guild.id,
            user_id=interaction.user.id,
            action="kick",
            details=f"Expulso: {membro} | Motivo: {motivo}",
        )

        embed = success_embed("Membro Expulso", f"**{membro}** foi expulso com sucesso.")
        embed.add_field(name="Motivo", value=f"> {motivo}", inline=False)
        embed.add_field(name="Moderador", value=f"> {interaction.user.mention}", inline=True)
        embed.set_thumbnail(url=membro.display_avatar.url)
        embed.set_footer(text="Shard App • Sua solução completa para servidores Discord")

        await interaction.response.send_message(embed=embed)

    # ── /limpar ───────────────────────────────────────────────────────────────

    @app_commands.command(
        name="limpar", description="Apaga mensagens do canal atual"
    )
    @app_commands.describe(
        quantidade="Número de mensagens para deletar (1-100)",
        usuario="Apagar mensagens apenas deste usuário (opcional)",
    )
    async def limpar(
        self,
        interaction: discord.Interaction,
        quantidade: app_commands.Range[int, 1, 100],
        usuario: discord.Member | None = None,
    ) -> None:
        if not interaction.guild or not isinstance(interaction.channel, discord.TextChannel):
            await interaction.response.send_message(
                embed=error_embed("Erro", "Use em um canal de texto."), ephemeral=True
            )
            return

        if not interaction.user.guild_permissions.manage_messages:  # type: ignore
            await interaction.response.send_message(
                embed=error_embed("Permissão Negada", "Você precisa de **Gerenciar Mensagens**."),
                ephemeral=True,
            )
            return

        if not interaction.guild.me.guild_permissions.manage_messages:
            await interaction.response.send_message(
                embed=error_embed("Permissão Insuficiente", "Não tenho permissão para gerenciar mensagens."),
                ephemeral=True,
            )
            return

        await interaction.response.defer(ephemeral=True)

        def check(msg: discord.Message) -> bool:
            if usuario:
                return msg.author == usuario
            return True

        try:
            deleted = await interaction.channel.purge(limit=quantidade, check=check)
        except discord.HTTPException as e:
            await interaction.followup.send(
                embed=error_embed("Erro", f"Não foi possível limpar: {e}"), ephemeral=True
            )
            return

        await self._send_log(
            interaction.guild,
            f"{EMOJI['clear']} **{len(deleted)}** mensagens apagadas em {interaction.channel.mention} por **{interaction.user}**."
            + (f" (filtro: {usuario})" if usuario else ""),
            "clear",
        )
        await self.bot.db.add_audit(
            guild_id=interaction.guild.id,
            user_id=interaction.user.id,
            action="clear",
            details=f"{len(deleted)} mensagens removidas | Canal: {interaction.channel.name}",
        )

        embed = success_embed(
            "Mensagens Apagadas",
            f"**{len(deleted)}** mensagens foram removidas com sucesso.",
        )
        embed.add_field(name="Canal", value=interaction.channel.mention, inline=True)
        embed.add_field(name="Moderador", value=interaction.user.mention, inline=True)
        embed.set_footer(text="Shard App • Sua solução completa para servidores Discord")

        await interaction.followup.send(embed=embed, ephemeral=True)

    # ── Helpers ───────────────────────────────────────────────────────────────

    async def _send_log(
        self, guild: discord.Guild, message: str, log_type: str
    ) -> None:
        """Envia log de moderação."""
        if not self.bot.db:
            return
        settings = await self.bot.db.get_log_settings(guild.id)
        if not settings:
            return

        log_channel_id = settings.get("log_channel_id")
        if not log_channel_id:
            return

        channel = guild.get_channel(log_channel_id)
        if not channel or not isinstance(channel, discord.TextChannel):
            return

        color_map = {"ban": 0xE74C3C, "kick": 0xE67E22, "clear": 0x95A5A6}
        embed = discord.Embed(
            description=message,
            color=color_map.get(log_type, 0x00BFFF),
        )
        embed.set_footer(text=f"Shard App — Log | {log_type}")

        try:
            await channel.send(embed=embed)
        except discord.HTTPException:
            pass


async def setup(bot: "ShardBot") -> None:
    await bot.add_cog(ModerationCommands(bot))
