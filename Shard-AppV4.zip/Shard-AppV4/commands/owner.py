"""
Shard App — Comandos do Desenvolvedor
/dar_premium, /tirar_premium, /ver_premium
Exclusivos do dono do bot (BOT_OWNER_ID).
"""

from __future__ import annotations

import datetime
import logging
from typing import TYPE_CHECKING

import discord
from discord import app_commands
from discord.ext import commands

from config.settings import EMOJI, PLANS, SERVIDOR_OFICIAL_URL, FOOTER_TEXT, THUMBNAIL_URL
from utils.checks import is_owner
from utils.embeds import error_embed, success_embed, owner_only_embed
from utils.helpers import days_remaining, safe_send_dm

if TYPE_CHECKING:
    from main import ShardBot

logger = logging.getLogger("shard.commands.owner")

PLAN_CHOICES = [
    app_commands.Choice(name="🥉 Bronze Shard",    value="bronze"),
    app_commands.Choice(name="💚 Esmeralda Shard", value="emerald"),
    app_commands.Choice(name="💎 Diamante Shard",  value="diamond"),
]


class OwnerCommands(commands.Cog):
    """Comandos exclusivos do desenvolvedor do Shard App."""

    def __init__(self, bot: "ShardBot") -> None:
        self.bot = bot

    # ── Guard: bloquear qualquer usuário que não seja o dono ──────────────────

    async def _check_owner(self, interaction: discord.Interaction) -> bool:
        """Verifica se o usuário é o dono do bot. Responde automaticamente se não for."""
        if is_owner(interaction.user.id):
            return True
        await interaction.response.send_message(
            embed=owner_only_embed(), ephemeral=True
        )
        return False

    # ── /dar_premium ──────────────────────────────────────────────────────────

    @app_commands.command(
        name="dar_premium",
        description="[DEV] Concede um plano Premium a um usuário",
    )
    @app_commands.describe(
        usuario="Usuário que receberá o Premium",
        plano="Plano a ser concedido",
        dias="Quantidade de dias de acesso",
    )
    @app_commands.choices(plano=PLAN_CHOICES)
    async def dar_premium(
        self,
        interaction: discord.Interaction,
        usuario: discord.User,
        plano: app_commands.Choice[str],
        dias: app_commands.Range[int, 1, 3650],
    ) -> None:
        if not await self._check_owner(interaction):
            return

        await self.bot.db.ensure_user(usuario.id, str(usuario))
        expires_at = await self.bot.db.set_premium(
            user_id=usuario.id,
            plan=plano.value,
            days=dias,
            granted_by=interaction.user.id,
        )

        plan_data = PLANS[plano.value]
        now = datetime.datetime.utcnow()

        # Embed de confirmação para o dono
        embed = success_embed(
            "Premium Concedido!",
            f"O plano **{plan_data['name']}** foi concedido a **{usuario}** com sucesso.",
        )
        embed.add_field(name="Plano",        value=f"> {plan_data['emoji']} {plan_data['name']}", inline=True)
        embed.add_field(name="Dias",         value=f"> `{dias}` dias",                           inline=True)
        embed.add_field(name="Expira em",    value=f"> <t:{int(expires_at.timestamp())}:F>",     inline=True)
        embed.add_field(name="Usuário",      value=f"> {usuario.mention} (`{usuario.id}`)",     inline=False)
        embed.set_thumbnail(url=usuario.display_avatar.url)
        embed.set_footer(text=FOOTER_TEXT)
        await interaction.response.send_message(embed=embed, ephemeral=True)

        # DM ao usuário que recebeu o Premium
        dm_embed = discord.Embed(
            title=f"🎉  Parabéns! Você recebeu um plano Premium!",
            description=(
                f"O desenvolvedor do **Shard App** concedeu a você o plano "
                f"**{plan_data['emoji']} {plan_data['name']}**!"
            ),
            color=plan_data["color"],
        )
        dm_embed.add_field(
            name=f"✨  Benefícios",
            value="\n".join(f"> {b}" for b in plan_data["benefits"]),
            inline=False,
        )
        dm_embed.add_field(name="📅  Ativado em",  value=f"> <t:{int(now.timestamp())}:F>",          inline=True)
        dm_embed.add_field(name="⏳  Expira em",   value=f"> <t:{int(expires_at.timestamp())}:F>",  inline=True)
        dm_embed.add_field(name="👑  Concedido por", value=f"> {interaction.user}",                  inline=True)
        dm_embed.set_thumbnail(url=THUMBNAIL_URL)
        dm_embed.set_footer(text=FOOTER_TEXT)

        dm_view = discord.ui.View(timeout=None)
        dm_view.add_item(
            discord.ui.Button(
                label=f"{EMOJI['rocket']}  Servidor Oficial",
                style=discord.ButtonStyle.link,
                url=SERVIDOR_OFICIAL_URL,
            )
        )
        await safe_send_dm(usuario, embed=dm_embed, view=dm_view)

        logger.info(
            "Premium concedido: user=%d plano=%s dias=%d by=%d",
            usuario.id, plano.value, dias, interaction.user.id,
        )

    # ── /tirar_premium ────────────────────────────────────────────────────────

    @app_commands.command(
        name="tirar_premium",
        description="[DEV] Remove o plano Premium de um usuário",
    )
    @app_commands.describe(usuario="Usuário que terá o Premium removido")
    async def tirar_premium(
        self,
        interaction: discord.Interaction,
        usuario: discord.User,
    ) -> None:
        if not await self._check_owner(interaction):
            return

        # Verificar plano atual
        current = await self.bot.db.get_premium(usuario.id)
        if current.get("plan", "free") == "free":
            await interaction.response.send_message(
                embed=error_embed(
                    "Sem Premium",
                    f"**{usuario}** não possui um plano Premium ativo.",
                ),
                ephemeral=True,
            )
            return

        plan_name = PLANS.get(current["plan"], {}).get("name", current["plan"])
        await self.bot.db.remove_premium(usuario.id, interaction.user.id)

        embed = success_embed(
            "Premium Removido",
            f"O plano **{plan_name}** foi removido de **{usuario}**.",
        )
        embed.set_thumbnail(url=usuario.display_avatar.url)
        embed.set_footer(text=FOOTER_TEXT)
        await interaction.response.send_message(embed=embed, ephemeral=True)

        # DM ao usuário informando que o Premium foi encerrado
        dm_embed = discord.Embed(
            title="⚠️  Plano Premium Encerrado",
            description=(
                f"Seu plano **{plan_name}** no **Shard App** foi encerrado.\n\n"
                "Para reativar, acesse nosso servidor oficial e adquira um novo plano."
            ),
            color=0xE74C3C,
        )
        dm_embed.set_thumbnail(url=THUMBNAIL_URL)
        dm_embed.set_footer(text=FOOTER_TEXT)

        dm_view = discord.ui.View(timeout=None)
        dm_view.add_item(
            discord.ui.Button(
                label=f"{EMOJI['rocket']}  Servidor Oficial",
                style=discord.ButtonStyle.link,
                url=SERVIDOR_OFICIAL_URL,
            )
        )
        await safe_send_dm(usuario, embed=dm_embed, view=dm_view)

        logger.info("Premium removido: user=%d by=%d", usuario.id, interaction.user.id)

    # ── /ver_premium ──────────────────────────────────────────────────────────

    @app_commands.command(
        name="ver_premium",
        description="[DEV] Consulta o plano Premium de um usuário",
    )
    @app_commands.describe(usuario="Usuário para consultar")
    async def ver_premium(
        self,
        interaction: discord.Interaction,
        usuario: discord.User,
    ) -> None:
        if not await self._check_owner(interaction):
            return

        current  = await self.bot.db.get_premium(usuario.id)
        history  = await self.bot.db.get_premium_history(usuario.id)
        plan_key = current.get("plan", "free")
        plan     = PLANS.get(plan_key, PLANS["free"])

        dr = days_remaining(current.get("expires_at"))

        activated_ts = (
            f"<t:{int(datetime.datetime.fromisoformat(current['activated_at']).timestamp())}:F>"
            if current.get("activated_at") else "N/A"
        )
        expires_ts = (
            f"<t:{int(datetime.datetime.fromisoformat(current['expires_at']).timestamp())}:F>"
            if current.get("expires_at") else "N/A"
        )

        embed = discord.Embed(
            title=f"{EMOJI['nitro']}  Premium de {usuario}",
            color=plan["color"],
        )
        embed.set_thumbnail(url=usuario.display_avatar.url)
        embed.set_footer(text=FOOTER_TEXT)

        embed.add_field(
            name="Informações",
            value=(
                f"> **Plano:** {plan['emoji']} {plan['name']}\n"
                f"> **ID:** `{usuario.id}`\n"
                f"> **Dias restantes:** `{dr if dr is not None else 'N/A'}`\n"
                f"> **Ativado em:** {activated_ts}\n"
                f"> **Expira em:** {expires_ts}"
            ),
            inline=False,
        )

        if history:
            hist_lines = []
            for h in history[:5]:
                action_emoji = "✅" if h["action"] == "granted" else "❌"
                hist_lines.append(
                    f"> {action_emoji} **{h['plan']}** — {h['action']} em `{h['timestamp'][:10]}`"
                )
            embed.add_field(
                name="📋  Histórico",
                value="\n".join(hist_lines),
                inline=False,
            )

        await interaction.response.send_message(embed=embed, ephemeral=True)


async def setup(bot: "ShardBot") -> None:
    await bot.add_cog(OwnerCommands(bot))
