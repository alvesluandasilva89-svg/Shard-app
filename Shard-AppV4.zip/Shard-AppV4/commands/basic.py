"""
Shard App — Comandos Básicos
/ping, /ajuda, /perfil, /plans, /userinfo, /serverinfo
"""

from __future__ import annotations

import logging
import time
from typing import TYPE_CHECKING

import discord
from discord import app_commands
from discord.ext import commands

from utils.embeds import (
    ping_embed, help_embed, profile_embed, plans_embed,
    userinfo_embed, serverinfo_embed, error_embed,
)
from utils.checks import get_user_plan
from utils.helpers import days_remaining
from views.premium_views import PlansView, ProfileView, HelpView

if TYPE_CHECKING:
    from main import ShardBot

logger = logging.getLogger("shard.commands.basic")


class BasicCommands(commands.Cog):
    """Comandos básicos acessíveis por todos os usuários."""

    def __init__(self, bot: "ShardBot") -> None:
        self.bot = bot

    # ── /ping ─────────────────────────────────────────────────────────────────

    @app_commands.command(name="ping", description="Verifica a latência do bot")
    async def ping(self, interaction: discord.Interaction) -> None:
        latency = round(self.bot.latency * 1000)
        await interaction.response.send_message(
            embed=ping_embed(latency), ephemeral=True
        )

    # ── /ajuda ────────────────────────────────────────────────────────────────

    @app_commands.command(name="ajuda", description="Central de ajuda — todos os comandos do Shard App")
    async def ajuda(self, interaction: discord.Interaction) -> None:
        guild_count = len(self.bot.guilds)
        view = HelpView(guild_count=guild_count)
        await interaction.response.send_message(
            embed=help_embed(guild_count=guild_count),
            view=view,
            ephemeral=True,
        )

    # ── /perfil ───────────────────────────────────────────────────────────────

    @app_commands.command(name="perfil", description="Exibe seu perfil e estatísticas no Shard App")
    async def perfil(self, interaction: discord.Interaction) -> None:
        user = interaction.user
        await self.bot.db.ensure_user(user.id, str(user))

        premium_data  = await self.bot.db.get_premium(user.id)
        daily_used    = await self.bot.db.get_daily_usage(user.id)
        backup_count  = await self.bot.db.get_backup_count(user.id)
        total_servers = await self.bot.db.get_server_creation_count(user.id)
        dr = days_remaining(premium_data.get("expires_at"))

        member = (
            interaction.guild.get_member(user.id)
            if interaction.guild else None
        ) or user

        embed = profile_embed(
            user=member,
            premium_data=premium_data,
            daily_used=daily_used,
            backup_count=backup_count,
            total_servers=total_servers,
            days_remaining=dr,
        )
        await interaction.response.send_message(
            embed=embed, view=ProfileView(), ephemeral=True
        )

    # ── /plans ────────────────────────────────────────────────────────────────

    @app_commands.command(name="plans", description="Veja os planos Premium do Shard App")
    async def plans(self, interaction: discord.Interaction) -> None:
        await interaction.response.send_message(
            embed=plans_embed(), view=PlansView(), ephemeral=True
        )

    # ── /userinfo ─────────────────────────────────────────────────────────────

    @app_commands.command(name="userinfo", description="Informações detalhadas de um usuário")
    @app_commands.describe(usuario="Usuário para consultar (padrão: você mesmo)")
    async def userinfo(
        self,
        interaction: discord.Interaction,
        usuario: discord.Member | None = None,
    ) -> None:
        if not interaction.guild:
            await interaction.response.send_message(
                embed=error_embed("Erro", "Use este comando em um servidor."),
                ephemeral=True,
            )
            return

        target = usuario or interaction.user
        member = interaction.guild.get_member(target.id) or target

        await interaction.response.send_message(
            embed=userinfo_embed(member),  # type: ignore
            ephemeral=True,
        )

    # ── /serverinfo ───────────────────────────────────────────────────────────

    @app_commands.command(name="serverinfo", description="Informações detalhadas do servidor atual")
    async def serverinfo(self, interaction: discord.Interaction) -> None:
        if not interaction.guild:
            await interaction.response.send_message(
                embed=error_embed("Erro", "Use este comando em um servidor."),
                ephemeral=True,
            )
            return
        await interaction.response.send_message(
            embed=serverinfo_embed(interaction.guild), ephemeral=True
        )


async def setup(bot: "ShardBot") -> None:
    await bot.add_cog(BasicCommands(bot))
