"""
Shard App — Comandos de Criação
/servidor criar, /templates, /categoria criar, /canal criar, /cargos criar
"""

from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING

import discord
from discord import app_commands
from discord.ext import commands

from config.settings import EMOJI, TEMPLATES
from utils.checks import get_user_plan, check_daily_limit, plan_meets_requirement
from utils.embeds import (
    error_embed, loading_embed, premium_required_embed, daily_limit_embed,
    success_embed,
)
from views.premium_views import PremiumRequiredView, DailyLimitView
from views.server_views import ServerCreateModal, TemplatesSelectView

if TYPE_CHECKING:
    from main import ShardBot

logger = logging.getLogger("shard.commands.server")


class ServerCommands(commands.Cog):
    """Comandos de criação e gestão de estrutura de servidores."""

    def __init__(self, bot: "ShardBot") -> None:
        self.bot = bot

    servidor_group = app_commands.Group(
        name="servidor", description="Comandos de criação e gestão de servidor"
    )

    # ── /servidor criar ───────────────────────────────────────────────────────

    @servidor_group.command(name="criar", description="Cria um servidor completo usando Inteligência Artificial")
    async def servidor_criar(self, interaction: discord.Interaction) -> None:
        """Etapa 1 → Verificação → Etapa 2 → Modal."""
        user = interaction.user

        if not interaction.guild:
            await interaction.response.send_message(
                embed=error_embed("Erro", "Este comando só pode ser usado dentro de um servidor."),
                ephemeral=True,
            )
            return

        # Garantir usuário no banco
        await self.bot.db.ensure_user(user.id, str(user))

        # Verificar permissões no servidor
        if not interaction.guild.me.guild_permissions.manage_channels:
            await interaction.response.send_message(
                embed=error_embed(
                    "Permissão Insuficiente",
                    "Preciso da permissão **Gerenciar Canais** para criar a estrutura do servidor.",
                ),
                ephemeral=True,
            )
            return

        # Obter plano atual
        plan = await get_user_plan(self.bot.db, user.id)

        # Verificar limite diário
        can_create, used, limit = await check_daily_limit(self.bot.db, user.id, plan)

        if not can_create:
            await interaction.response.send_message(
                embed=daily_limit_embed(plan, used, limit),
                view=DailyLimitView(),
                ephemeral=True,
            )
            return

        # Etapa 2: Abrir modal
        modal = ServerCreateModal(
            ai_service=self.bot.ai_service,
            backup_service=self.bot.backup_service,
            db=self.bot.db,
            user_plan=plan,
        )
        await interaction.response.send_modal(modal)

    # ── /templates ────────────────────────────────────────────────────────────

    @app_commands.command(
        name="templates", description="Escolha um template pronto para criar seu servidor"
    )
    async def templates(self, interaction: discord.Interaction) -> None:
        user = interaction.user
        await self.bot.db.ensure_user(user.id, str(user))

        plan = await get_user_plan(self.bot.db, user.id)
        can_create, used, limit = await check_daily_limit(self.bot.db, user.id, plan)

        if not can_create:
            await interaction.response.send_message(
                embed=daily_limit_embed(plan, used, limit),
                view=DailyLimitView(),
                ephemeral=True,
            )
            return

        embed = discord.Embed(
            title=f"{EMOJI['categories']}  Templates Disponíveis",
            description=(
                "Escolha um template abaixo para criar um servidor completo.\n"
                "Templates marcados com **Premium** requerem plano Bronze ou superior."
            ),
            color=0x00BFFF,
        )
        embed.set_thumbnail(url="https://i.ibb.co/8nMttsRX/6fa3f30915ff9c68cefe6f35cf07c080.jpg")
        embed.set_footer(text="Shard App • Sua solução completa para servidores Discord")

        view = TemplatesSelectView(
            ai_service=self.bot.ai_service,
            backup_service=self.bot.backup_service,
            db=self.bot.db,
            user_plan=plan,
        )
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)

    # ── /categoria criar ──────────────────────────────────────────────────────

    @app_commands.command(
        name="categoria", description="Cria uma nova categoria usando Inteligência Artificial"
    )
    @app_commands.describe(descricao="Descreva a categoria que deseja criar")
    async def categoria_criar(
        self, interaction: discord.Interaction, descricao: str
    ) -> None:
        if not interaction.guild:
            await interaction.response.send_message(
                embed=error_embed("Erro", "Use este comando em um servidor."), ephemeral=True
            )
            return

        if not interaction.guild.me.guild_permissions.manage_channels:
            await interaction.response.send_message(
                embed=error_embed("Permissão Insuficiente", "Preciso de permissão para gerenciar canais."),
                ephemeral=True,
            )
            return

        await interaction.response.defer(ephemeral=True, thinking=True)

        plan = await get_user_plan(self.bot.db, interaction.user.id)
        cat_data = await self.bot.ai_service.generate_category(descricao, plan)

        if not cat_data:
            await interaction.followup.send(
                embed=error_embed("Erro na IA", "Não foi possível gerar a categoria. Tente novamente."),
                ephemeral=True,
            )
            return

        # Prévia e confirmação
        embed = discord.Embed(
            title=f"{EMOJI['categories']}  Prévia da Categoria",
            description=f"**{cat_data.get('name', 'Nova Categoria')}**",
            color=0x00BFFF,
        )
        channels_preview = "\n".join(
            f"> `{ch['name']}` ({ch.get('type', 'text')})"
            for ch in cat_data.get("channels", [])[:10]
        )
        if channels_preview:
            embed.add_field(name=f"{EMOJI['channels']}  Canais", value=channels_preview, inline=False)
        embed.set_footer(text="Shard App • Sua solução completa para servidores Discord")
        embed.set_thumbnail(url="https://i.ibb.co/8nMttsRX/6fa3f30915ff9c68cefe6f35cf07c080.jpg")

        view = CategoryConfirmView(
            cat_data=cat_data,
            guild=interaction.guild,
        )
        await interaction.followup.send(embed=embed, view=view, ephemeral=True)

    # ── /canal criar ──────────────────────────────────────────────────────────

    @app_commands.command(
        name="canal", description="Cria um novo canal usando Inteligência Artificial"
    )
    @app_commands.describe(descricao="Descreva o canal que deseja criar")
    async def canal_criar(
        self, interaction: discord.Interaction, descricao: str
    ) -> None:
        if not interaction.guild:
            await interaction.response.send_message(
                embed=error_embed("Erro", "Use este comando em um servidor."), ephemeral=True
            )
            return

        await interaction.response.defer(ephemeral=True, thinking=True)

        plan = await get_user_plan(self.bot.db, interaction.user.id)
        ch_data = await self.bot.ai_service.generate_channel(descricao, plan)

        if not ch_data:
            await interaction.followup.send(
                embed=error_embed("Erro na IA", "Não foi possível gerar o canal. Tente novamente."),
                ephemeral=True,
            )
            return

        embed = discord.Embed(
            title=f"{EMOJI['channels']}  Prévia do Canal",
            color=0x00BFFF,
        )
        embed.add_field(name="Nome", value=f"`{ch_data.get('name', 'novo-canal')}`", inline=True)
        embed.add_field(name="Tipo", value=f"`{ch_data.get('type', 'text')}`", inline=True)
        if ch_data.get("topic"):
            embed.add_field(name="Tópico", value=ch_data["topic"][:100], inline=False)
        embed.set_footer(text="Shard App • Sua solução completa para servidores Discord")
        embed.set_thumbnail(url="https://i.ibb.co/8nMttsRX/6fa3f30915ff9c68cefe6f35cf07c080.jpg")

        view = ChannelConfirmView(ch_data=ch_data, guild=interaction.guild)
        await interaction.followup.send(embed=embed, view=view, ephemeral=True)

    # ── /cargos criar ─────────────────────────────────────────────────────────

    @app_commands.command(
        name="cargos", description="Cria cargos automaticamente usando Inteligência Artificial"
    )
    @app_commands.describe(descricao="Descreva os cargos que deseja criar")
    async def cargos_criar(
        self, interaction: discord.Interaction, descricao: str
    ) -> None:
        if not interaction.guild:
            await interaction.response.send_message(
                embed=error_embed("Erro", "Use este comando em um servidor."), ephemeral=True
            )
            return

        await interaction.response.defer(ephemeral=True, thinking=True)

        plan = await get_user_plan(self.bot.db, interaction.user.id)
        roles = await self.bot.ai_service.generate_roles(descricao, plan)

        if not roles:
            await interaction.followup.send(
                embed=error_embed("Erro na IA", "Não foi possível gerar os cargos. Tente novamente."),
                ephemeral=True,
            )
            return

        preview_lines = "\n".join(
            f"> `{r.get('name', '?')}` — `{r.get('color', '#000000')}`"
            for r in roles[:10]
        )
        embed = discord.Embed(
            title=f"{EMOJI['crown']}  Prévia dos Cargos",
            description=preview_lines,
            color=0x00BFFF,
        )
        embed.add_field(name="Total", value=f"`{len(roles)}` cargos", inline=True)
        embed.set_footer(text="Shard App • Sua solução completa para servidores Discord")
        embed.set_thumbnail(url="https://i.ibb.co/8nMttsRX/6fa3f30915ff9c68cefe6f35cf07c080.jpg")

        view = RolesConfirmView(roles=roles, guild=interaction.guild)
        await interaction.followup.send(embed=embed, view=view, ephemeral=True)


# ── Views de Confirmação Inline ───────────────────────────────────────────────

class CategoryConfirmView(discord.ui.View):
    def __init__(self, cat_data: dict, guild: discord.Guild) -> None:
        super().__init__(timeout=120)
        self.cat_data = cat_data
        self.guild = guild

    @discord.ui.button(label="✅ Criar Categoria", style=discord.ButtonStyle.success)
    async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await interaction.response.defer()
        try:
            category = await self.guild.create_category(
                name=self.cat_data.get("name", "Nova Categoria"),
                reason="Shard App — /categoria criar",
            )
            for ch in self.cat_data.get("channels", [])[:50]:
                await asyncio.sleep(0.3)
                ch_type = ch.get("type", "text")
                if ch_type == "voice":
                    await self.guild.create_voice_channel(name=ch["name"], category=category)
                elif ch_type == "forum":
                    await self.guild.create_forum(name=ch["name"], category=category, topic=ch.get("topic", ""))
                else:
                    await self.guild.create_text_channel(name=ch["name"], category=category, topic=ch.get("topic", ""))

            await interaction.edit_original_response(
                embed=success_embed("Categoria Criada!", f"**{category.name}** foi criada com sucesso."),
                view=None,
            )
        except discord.HTTPException as e:
            await interaction.edit_original_response(
                embed=error_embed("Erro", f"Falha ao criar categoria: {e}"),
                view=None,
            )

    @discord.ui.button(label="❌ Cancelar", style=discord.ButtonStyle.danger)
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await interaction.response.edit_message(
            embed=error_embed("Cancelado", "Criação de categoria cancelada."), view=None
        )


class ChannelConfirmView(discord.ui.View):
    def __init__(self, ch_data: dict, guild: discord.Guild) -> None:
        super().__init__(timeout=120)
        self.ch_data = ch_data
        self.guild = guild

    @discord.ui.button(label="✅ Criar Canal", style=discord.ButtonStyle.success)
    async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await interaction.response.defer()
        try:
            ch_type = self.ch_data.get("type", "text")
            name = self.ch_data.get("name", "novo-canal")
            if ch_type == "voice":
                ch = await self.guild.create_voice_channel(name=name, reason="Shard App — /canal criar")
            elif ch_type == "forum":
                ch = await self.guild.create_forum(name=name, topic=self.ch_data.get("topic", ""), reason="Shard App — /canal criar")
            else:
                ch = await self.guild.create_text_channel(
                    name=name,
                    topic=self.ch_data.get("topic", ""),
                    nsfw=self.ch_data.get("nsfw", False),
                    slowmode_delay=self.ch_data.get("slowmode", 0),
                    reason="Shard App — /canal criar",
                )
            await interaction.edit_original_response(
                embed=success_embed("Canal Criado!", f"**{ch.name}** foi criado com sucesso."),
                view=None,
            )
        except discord.HTTPException as e:
            await interaction.edit_original_response(
                embed=error_embed("Erro", f"Falha ao criar canal: {e}"),
                view=None,
            )

    @discord.ui.button(label="❌ Cancelar", style=discord.ButtonStyle.danger)
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await interaction.response.edit_message(
            embed=error_embed("Cancelado", "Criação de canal cancelada."), view=None
        )


class RolesConfirmView(discord.ui.View):
    def __init__(self, roles: list[dict], guild: discord.Guild) -> None:
        super().__init__(timeout=120)
        self.roles = roles
        self.guild = guild

    @discord.ui.button(label="✅ Criar Cargos", style=discord.ButtonStyle.success)
    async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await interaction.response.defer()
        created = 0
        errors = []
        for r in self.roles[:20]:
            try:
                hex_color = r.get("color", "#000000").replace("#", "")
                color = discord.Color(int(hex_color, 16)) if hex_color else discord.Color.default()
                from utils.helpers import role_permissions_from_list
                perms = role_permissions_from_list(r.get("permissions", []))
                await self.guild.create_role(
                    name=r.get("name", "Cargo"),
                    color=color,
                    permissions=perms,
                    hoist=r.get("hoist", False),
                    mentionable=r.get("mentionable", False),
                    reason="Shard App — /cargos criar",
                )
                created += 1
                await asyncio.sleep(0.4)
            except discord.HTTPException as e:
                errors.append(r.get("name", "?"))

        embed = success_embed("Cargos Criados!", f"**{created}** cargos foram criados com sucesso.")
        if errors:
            embed.add_field(name="⚠️ Falhas", value=", ".join(f"`{e}`" for e in errors), inline=False)
        await interaction.edit_original_response(embed=embed, view=None)

    @discord.ui.button(label="❌ Cancelar", style=discord.ButtonStyle.danger)
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await interaction.response.edit_message(
            embed=error_embed("Cancelado", "Criação de cargos cancelada."), view=None
        )


async def setup(bot: "ShardBot") -> None:
    await bot.add_cog(ServerCommands(bot))
