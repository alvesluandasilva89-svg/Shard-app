"""
Shard App — Modelo de Usuário
Dataclass para representar um usuário e seu estado no sistema.
"""

from __future__ import annotations

import datetime
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class UserProfile:
    """Perfil completo de um usuário no Shard App."""

    user_id: int
    username: str
    plan: str = "free"
    expires_at: Optional[str] = None
    activated_at: Optional[str] = None
    granted_by: Optional[int] = None
    daily_used: int = 0
    backup_count: int = 0
    total_servers: int = 0
    created_at: str = field(default_factory=lambda: datetime.datetime.utcnow().isoformat())

    @property
    def days_remaining(self) -> Optional[int]:
        """Retorna os dias restantes do plano."""
        if not self.expires_at:
            return None
        exp = datetime.datetime.fromisoformat(self.expires_at)
        delta = exp - datetime.datetime.utcnow()
        return max(0, delta.days)

    @property
    def is_premium(self) -> bool:
        return self.plan != "free"

    @property
    def plan_expired(self) -> bool:
        if not self.expires_at:
            return False
        exp = datetime.datetime.fromisoformat(self.expires_at)
        return exp < datetime.datetime.utcnow()
